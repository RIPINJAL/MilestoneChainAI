"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  CheckCircle,
  Lock,
  Shield,
  DollarSign,
  ArrowRight,
} from "lucide-react"
import type { Project } from "./project-card"

interface InvestDialogProps {
  project: Project | null
  isOpen: boolean
  onClose: () => void
  walletBalance: number
  onInvestComplete: (amount: number) => void
}

export function InvestDialog({
  project,
  isOpen,
  onClose,
  walletBalance,
  onInvestComplete,
}: InvestDialogProps) {
  const [step, setStep] = useState<"amount" | "confirm" | "processing" | "success">("amount")
  const [amount, setAmount] = useState("")
  const [selectedMilestone, setSelectedMilestone] = useState<string | null>(null)

  if (!project) return null

  const milestones = [
    { id: "1", name: "Beta Launch", amount: 50000, remaining: 25000 },
    { id: "2", name: "Full Product Launch", amount: 75000, remaining: 75000 },
    { id: "3", name: "Scale & Optimization", amount: 40000, remaining: 40000 },
  ]

  const handleInvest = async () => {
    setStep("processing")
    await new Promise((resolve) => setTimeout(resolve, 2000))
    onInvestComplete(parseFloat(amount))
    setStep("success")
  }

  const handleClose = () => {
    setStep("amount")
    setAmount("")
    setSelectedMilestone(null)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg border-border bg-card">
        <DialogHeader>
          <DialogTitle className="text-foreground">
            {step === "success" ? "Investment Successful" : `Invest in ${project.name}`}
          </DialogTitle>
        </DialogHeader>

        {step === "amount" && (
          <div className="space-y-6 py-4">
            <div className="rounded-lg border border-border bg-secondary p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  AI Risk Score
                </span>
                <Badge
                  variant="outline"
                  className={`text-xs ${
                    project.riskScore <= 30
                      ? "border-success text-success"
                      : project.riskScore <= 60
                        ? "border-warning text-warning"
                        : "border-destructive text-destructive"
                  }`}
                >
                  <Shield className="mr-1 h-3 w-3" />
                  {project.riskScore}% Risk
                </Badge>
              </div>
              <Progress value={100 - project.riskScore} className="mt-2 h-2" />
            </div>

            <div>
              <label className="text-sm text-muted-foreground">
                Select Milestone
              </label>
              <div className="mt-2 space-y-2">
                {milestones.map((milestone) => (
                  <button
                    key={milestone.id}
                    onClick={() => setSelectedMilestone(milestone.id)}
                    className={`w-full rounded-lg border p-3 text-left transition-colors ${
                      selectedMilestone === milestone.id
                        ? "border-primary bg-primary/10"
                        : "border-border bg-background hover:border-primary/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-foreground">
                        {milestone.name}
                      </span>
                      <span className="text-sm text-muted-foreground">
                        ${milestone.remaining.toLocaleString()} available
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm text-muted-foreground">
                Investment Amount (USD)
              </label>
              <div className="relative mt-2">
                <DollarSign className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="border-border bg-background pl-10 text-foreground"
                />
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Wallet Balance: ${walletBalance.toLocaleString()}
              </p>
            </div>

            <div className="flex gap-2">
              {[1000, 2500, 5000, 10000].map((amt) => (
                <Button
                  key={amt}
                  variant="outline"
                  size="sm"
                  onClick={() => setAmount(amt.toString())}
                  className="flex-1 text-xs"
                >
                  ${amt.toLocaleString()}
                </Button>
              ))}
            </div>

            <Button
              onClick={() => setStep("confirm")}
              disabled={!amount || !selectedMilestone || parseFloat(amount) > walletBalance}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Continue
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        )}

        {step === "confirm" && (
          <div className="space-y-6 py-4">
            <div className="rounded-lg border border-border bg-secondary p-4">
              <h4 className="font-medium text-foreground">Investment Summary</h4>
              <div className="mt-4 space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Project</span>
                  <span className="text-foreground">{project.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Milestone</span>
                  <span className="text-foreground">
                    {milestones.find((m) => m.id === selectedMilestone)?.name}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Amount</span>
                  <span className="font-medium text-foreground">
                    ${parseFloat(amount).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between border-t border-border pt-3">
                  <span className="text-muted-foreground">Escrow Lock</span>
                  <span className="flex items-center gap-1 text-primary">
                    <Lock className="h-3 w-3" />
                    Blockchain Secured
                  </span>
                </div>
              </div>
            </div>

            <div className="rounded-lg border border-primary/30 bg-primary/10 p-3">
              <div className="flex items-start gap-2">
                <Shield className="mt-0.5 h-4 w-4 text-primary" />
                <div>
                  <p className="text-sm font-medium text-primary">
                    Protected Investment
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Funds will be locked in blockchain escrow and only released
                    upon AI-verified milestone completion.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setStep("amount")}
                className="flex-1"
              >
                Back
              </Button>
              <Button
                onClick={handleInvest}
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Lock className="mr-2 h-4 w-4" />
                Confirm & Lock Funds
              </Button>
            </div>
          </div>
        )}

        {step === "processing" && (
          <div className="flex flex-col items-center py-12">
            <div className="relative">
              <div className="h-16 w-16 animate-spin rounded-full border-4 border-primary border-t-transparent" />
              <Lock className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 text-primary" />
            </div>
            <p className="mt-6 font-medium text-foreground">
              Processing Transaction
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Locking funds in blockchain escrow...
            </p>
          </div>
        )}

        {step === "success" && (
          <div className="flex flex-col items-center py-8">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-success/20">
              <CheckCircle className="h-10 w-10 text-success" />
            </div>
            <p className="mt-6 text-xl font-semibold text-foreground">
              Investment Successful!
            </p>
            <p className="mt-2 text-center text-sm text-muted-foreground">
              ${parseFloat(amount).toLocaleString()} has been locked in
              blockchain escrow for {project.name}.
            </p>
            <div className="mt-4 rounded-lg bg-secondary px-4 py-2">
              <p className="font-mono text-xs text-muted-foreground">
                TX: 0x7a8b9c...3d4e5f
              </p>
            </div>
            <Button onClick={handleClose} className="mt-6 w-full">
              Done
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
