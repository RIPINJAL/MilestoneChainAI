"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  MessageCircle,
  Send,
  Video,
  Phone,
  MoreVertical,
  Search,
  Plus,
  Check,
  CheckCheck,
  Paperclip,
  X,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  senderId: string
  senderName: string
  content: string
  timestamp: Date
  read: boolean
}

interface Conversation {
  id: string
  name: string
  role: "investor" | "founder" | "admin"
  avatar: string
  lastMessage: string
  lastMessageTime: Date
  unread: number
  online: boolean
  projectName?: string
}

const mockConversations: Conversation[] = [
  {
    id: "1",
    name: "Alex Chen",
    role: "investor",
    avatar: "AC",
    lastMessage: "Thanks for the milestone update!",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 5),
    unread: 2,
    online: true,
    projectName: "NeuraTech AI",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    role: "founder",
    avatar: "SJ",
    lastMessage: "The proof of utilization has been uploaded",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 30),
    unread: 0,
    online: true,
    projectName: "EcoTrack",
  },
  {
    id: "3",
    name: "Platform Admin",
    role: "admin",
    avatar: "PA",
    lastMessage: "Your milestone verification is complete",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 60 * 2),
    unread: 1,
    online: false,
  },
  {
    id: "4",
    name: "Michael Park",
    role: "investor",
    avatar: "MP",
    lastMessage: "Interested in your Series A round",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 60 * 24),
    unread: 0,
    online: false,
    projectName: "HealthSync",
  },
]

const mockMessages: Message[] = [
  {
    id: "1",
    senderId: "1",
    senderName: "Alex Chen",
    content: "Hi, I reviewed the latest milestone submission for NeuraTech AI.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60),
    read: true,
  },
  {
    id: "2",
    senderId: "me",
    senderName: "You",
    content: "Great! We have completed the MVP as outlined in milestone 3.",
    timestamp: new Date(Date.now() - 1000 * 60 * 45),
    read: true,
  },
  {
    id: "3",
    senderId: "1",
    senderName: "Alex Chen",
    content: "I can see the demo link you shared. The AI model performance looks impressive.",
    timestamp: new Date(Date.now() - 1000 * 60 * 30),
    read: true,
  },
  {
    id: "4",
    senderId: "me",
    senderName: "You",
    content: "Thank you! We achieved 94% accuracy on the benchmark tests.",
    timestamp: new Date(Date.now() - 1000 * 60 * 15),
    read: true,
  },
  {
    id: "5",
    senderId: "1",
    senderName: "Alex Chen",
    content: "Thanks for the milestone update! Can we schedule a call to discuss the next phase?",
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
    read: false,
  },
]

interface ChatPanelProps {
  userRole: "investor" | "founder" | "admin"
}

export function ChatPanel({ userRole }: ChatPanelProps) {
  const [conversations] = useState<Conversation[]>(mockConversations)
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<Message[]>(mockMessages)
  const [newMessage, setNewMessage] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [showMeetDialog, setShowMeetDialog] = useState(false)
  const [meetLink, setMeetLink] = useState("")
  const [scheduledTime, setScheduledTime] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    const message: Message = {
      id: Date.now().toString(),
      senderId: "me",
      senderName: "You",
      content: newMessage,
      timestamp: new Date(),
      read: false,
    }

    setMessages([...messages, message])
    setNewMessage("")
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleScheduleMeet = () => {
    // Generate a mock Google Meet link
    const mockMeetId = Math.random().toString(36).substring(2, 15)
    setMeetLink(`https://meet.google.com/${mockMeetId}`)
    
    // Add system message about the scheduled meeting
    const systemMessage: Message = {
      id: Date.now().toString(),
      senderId: "system",
      senderName: "System",
      content: `Meeting scheduled for ${new Date(scheduledTime).toLocaleString()}. Join: https://meet.google.com/${mockMeetId}`,
      timestamp: new Date(),
      read: true,
    }
    setMessages([...messages, systemMessage])
    setShowMeetDialog(false)
    setScheduledTime("")
  }

  const filteredConversations = conversations.filter(
    (conv) =>
      conv.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conv.projectName?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const formatTime = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const hours = Math.floor(diff / (1000 * 60 * 60))
    const minutes = Math.floor(diff / (1000 * 60))

    if (minutes < 60) return `${minutes}m ago`
    if (hours < 24) return `${hours}h ago`
    return date.toLocaleDateString()
  }

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "investor":
        return "bg-primary/10 text-primary"
      case "founder":
        return "bg-emerald-500/10 text-emerald-500"
      case "admin":
        return "bg-amber-500/10 text-amber-500"
      default:
        return "bg-secondary text-foreground"
    }
  }

  return (
    <Card className="flex h-[600px] flex-col border-border bg-card">
      <CardHeader className="border-b border-border px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5 text-primary" />
            <CardTitle className="text-base">Messages</CardTitle>
            <Badge variant="secondary" className="text-xs">
              {conversations.reduce((acc, c) => acc + c.unread, 0)} new
            </Badge>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="flex flex-1 gap-0 overflow-hidden p-0">
        {/* Conversation List */}
        <div className="flex w-80 flex-col border-r border-border">
          <div className="p-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-9 bg-secondary pl-9 text-sm"
              />
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="space-y-1 p-2">
              {filteredConversations.map((conversation) => (
                <button
                  key={conversation.id}
                  onClick={() => setSelectedConversation(conversation)}
                  className={cn(
                    "flex w-full items-start gap-3 rounded-lg p-3 text-left transition-colors hover:bg-secondary",
                    selectedConversation?.id === conversation.id && "bg-secondary"
                  )}
                >
                  <div className="relative">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {conversation.avatar}
                      </AvatarFallback>
                    </Avatar>
                    {conversation.online && (
                      <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-card bg-emerald-500" />
                    )}
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-foreground">
                        {conversation.name}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatTime(conversation.lastMessageTime)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="secondary"
                        className={cn("text-[10px]", getRoleBadgeColor(conversation.role))}
                      >
                        {conversation.role}
                      </Badge>
                      {conversation.projectName && (
                        <span className="truncate text-xs text-muted-foreground">
                          {conversation.projectName}
                        </span>
                      )}
                    </div>
                    <p className="mt-1 truncate text-xs text-muted-foreground">
                      {conversation.lastMessage}
                    </p>
                  </div>
                  {conversation.unread > 0 && (
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                      {conversation.unread}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Chat Area */}
        {selectedConversation ? (
          <div className="flex flex-1 flex-col">
            {/* Chat Header */}
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Avatar className="h-9 w-9">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {selectedConversation.avatar}
                    </AvatarFallback>
                  </Avatar>
                  {selectedConversation.online && (
                    <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card bg-emerald-500" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">
                    {selectedConversation.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {selectedConversation.online ? "Online" : "Offline"}
                    {selectedConversation.projectName &&
                      ` | ${selectedConversation.projectName}`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                  onClick={() => setShowMeetDialog(true)}
                >
                  <Video className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                >
                  <Phone className="h-4 w-4" />
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-foreground"
                    >
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setShowMeetDialog(true)}>
                      <Video className="mr-2 h-4 w-4" />
                      Schedule Google Meet
                    </DropdownMenuItem>
                    <DropdownMenuItem>View Profile</DropdownMenuItem>
                    <DropdownMenuItem>View Project</DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive">
                      Block User
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={cn(
                      "flex",
                      message.senderId === "me" ? "justify-end" : "justify-start",
                      message.senderId === "system" && "justify-center"
                    )}
                  >
                    {message.senderId === "system" ? (
                      <div className="rounded-lg bg-secondary px-4 py-2 text-xs text-muted-foreground">
                        {message.content}
                      </div>
                    ) : (
                      <div
                        className={cn(
                          "max-w-[70%] rounded-lg px-4 py-2",
                          message.senderId === "me"
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary text-foreground"
                        )}
                      >
                        <p className="text-sm">{message.content}</p>
                        <div
                          className={cn(
                            "mt-1 flex items-center justify-end gap-1 text-xs",
                            message.senderId === "me"
                              ? "text-primary-foreground/70"
                              : "text-muted-foreground"
                          )}
                        >
                          <span>
                            {message.timestamp.toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                          {message.senderId === "me" && (
                            message.read ? (
                              <CheckCheck className="h-3 w-3" />
                            ) : (
                              <Check className="h-3 w-3" />
                            )
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Message Input */}
            <div className="border-t border-border p-4">
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9 text-muted-foreground hover:text-foreground"
                >
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={handleKeyPress}
                  className="flex-1 bg-secondary"
                />
                <Button
                  size="icon"
                  className="h-9 w-9"
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim()}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <MessageCircle className="h-12 w-12 text-muted-foreground/50" />
            <p className="mt-4 text-lg font-medium text-foreground">
              Select a conversation
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              Choose a chat from the list to start messaging
            </p>
          </div>
        )}
      </CardContent>

      {/* Google Meet Dialog */}
      <Dialog open={showMeetDialog} onOpenChange={setShowMeetDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Video className="h-5 w-5 text-primary" />
              Schedule Google Meet
            </DialogTitle>
            <DialogDescription>
              Schedule a video call with {selectedConversation?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Select Date & Time
              </label>
              <Input
                type="datetime-local"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                className="bg-secondary"
              />
            </div>
            {meetLink && (
              <div className="rounded-lg bg-secondary p-3">
                <p className="mb-1 text-xs text-muted-foreground">Meet Link:</p>
                <p className="break-all text-sm text-primary">{meetLink}</p>
              </div>
            )}
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowMeetDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleScheduleMeet} disabled={!scheduledTime}>
              <Video className="mr-2 h-4 w-4" />
              Schedule Meeting
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
