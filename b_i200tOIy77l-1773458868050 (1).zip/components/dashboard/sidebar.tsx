"use client"

import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Search,
  Briefcase,
  TrendingUp,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Wallet,
  FileText,
  Shield,
  MessageCircle,
  Upload,
  Receipt,
  Users,
  FileCheck,
  Activity,
  UserCog,
} from "lucide-react"
import { Button } from "@/components/ui/button"

interface SidebarProps {
  activeView: string
  setActiveView: (view: string) => void
  isCollapsed: boolean
  setIsCollapsed: (collapsed: boolean) => void
  userRole: "investor" | "founder" | "admin"
  setUserRole: (role: "investor" | "founder" | "admin") => void
  onLogout?: () => void
}

const investorNavItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "discover", label: "Discover Projects", icon: Search },
  { id: "portfolio", label: "My Portfolio", icon: Briefcase },
  { id: "utilization", label: "Fund Utilization", icon: Receipt },
  { id: "messages", label: "Messages", icon: MessageCircle },
  { id: "wallet", label: "Wallet", icon: Wallet },
  { id: "analytics", label: "Analytics", icon: TrendingUp },
]

const founderNavItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "projects", label: "My Projects", icon: FileText },
  { id: "milestones", label: "Milestones", icon: Shield },
  { id: "proofs", label: "Submit Proofs", icon: Upload },
  { id: "utilization", label: "Fund Utilization", icon: Receipt },
  { id: "messages", label: "Messages", icon: MessageCircle },
  { id: "wallet", label: "Wallet", icon: Wallet },
  { id: "analytics", label: "Analytics", icon: TrendingUp },
]

const adminNavItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "reviews", label: "Milestone Reviews", icon: FileCheck },
  { id: "users", label: "User Management", icon: Users },
  { id: "transactions", label: "Transactions", icon: Activity },
  { id: "messages", label: "Messages", icon: MessageCircle },
  { id: "settings", label: "Platform Settings", icon: Settings },
]

export function Sidebar({
  activeView,
  setActiveView,
  isCollapsed,
  setIsCollapsed,
  userRole,
  setUserRole,
  onLogout,
}: SidebarProps) {
  const navItems = 
    userRole === "investor" 
      ? investorNavItems 
      : userRole === "founder" 
        ? founderNavItems 
        : adminNavItems

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "admin":
        return UserCog
      case "founder":
        return Briefcase
      default:
        return Users
    }
  }

  const getRoleColor = (role: string, isActive: boolean) => {
    if (!isActive) return "text-muted-foreground hover:text-foreground"
    switch (role) {
      case "admin":
        return "bg-amber-600 text-foreground"
      case "founder":
        return "bg-emerald-600 text-foreground"
      default:
        return "bg-primary text-primary-foreground"
    }
  }

  return (
    <aside
      className={cn(
        "flex flex-col border-r border-border bg-sidebar transition-all duration-300",
        isCollapsed ? "w-16" : "w-64"
      )}
    >
      <div className="flex h-16 items-center justify-between border-b border-border px-4">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Shield className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-semibold text-foreground">
              MilestoneChain
            </span>
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="h-8 w-8 text-muted-foreground hover:text-foreground"
        >
          {isCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <ChevronLeft className="h-4 w-4" />
          )}
        </Button>
      </div>

      <div className="flex-1 px-2 py-4">
        {!isCollapsed && (
          <div className="mb-4 flex gap-1 rounded-lg bg-secondary p-1">
            {(["investor", "founder", "admin"] as const).map((role) => {
              const Icon = getRoleIcon(role)
              return (
                <button
                  key={role}
                  onClick={() => {
                    setUserRole(role)
                    setActiveView("dashboard")
                  }}
                  className={cn(
                    "flex flex-1 items-center justify-center gap-1 rounded-md px-2 py-1.5 text-xs font-medium transition-colors",
                    getRoleColor(role, userRole === role)
                  )}
                >
                  <Icon className="h-3 w-3" />
                  {role.charAt(0).toUpperCase() + role.slice(1)}
                </button>
              )
            })}
          </div>
        )}

        <nav className="flex flex-col gap-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                activeView === item.id
                  ? "bg-sidebar-accent text-primary"
                  : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"
              )}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {!isCollapsed && <span>{item.label}</span>}
            </button>
          ))}
        </nav>
      </div>

      <div className="border-t border-border p-2">
        <button
          className={cn(
            "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
          )}
        >
          <Settings className="h-4 w-4 shrink-0" />
          {!isCollapsed && <span>Settings</span>}
        </button>
        <button
          onClick={onLogout}
          className={cn(
            "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
          )}
        >
          <LogOut className="h-4 w-4 shrink-0" />
          {!isCollapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  )
}
