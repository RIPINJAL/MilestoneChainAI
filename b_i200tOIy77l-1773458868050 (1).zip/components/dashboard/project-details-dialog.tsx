"use client"

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Shield,
  Clock,
  Users,
  Target,
  FileText,
  CheckCircle,
  ExternalLink,
} from "lucide-react"
import type { Project } from "./project-card"
import { MilestoneTimeline } from "./milestone-timeline"
import { AIRiskPanel } from "./ai-risk-panel"

interface ProjectDetailsDialogProps {
  project: Project | null
  isOpen: boolean
  onClose: () => void
  onInvest: (project: Project) => void
}

export function ProjectDetailsDialog({
  project,
  isOpen,
  onClose,
  onInvest,
}: ProjectDetailsDialogProps) {
  if (!project) return null

  const fundingProgress = (project.fundingRaised / project.fundingGoal) * 100

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-h-[90vh] max-w-4xl overflow-y-auto border-border bg-card">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="flex items-center gap-3 text-xl text-foreground">
                {project.name}
                <Badge variant="outline" className="text-xs text-muted-foreground">
                  {project.category}
                </Badge>
              </DialogTitle>
              <p className="mt-2 text-sm text-muted-foreground">
                {project.description}
              </p>
            </div>
          </div>
        </DialogHeader>

        <div className="mt-6 grid gap-4 md:grid-cols-4">
          <div className="rounded-lg bg-secondary p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Target className="h-4 w-4" />
              <span className="text-xs">Funding Goal</span>
            </div>
            <p className="mt-2 text-lg font-semibold text-foreground">
              ${project.fundingGoal.toLocaleString()}
            </p>
          </div>
          <div className="rounded-lg bg-secondary p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Shield className="h-4 w-4" />
              <span className="text-xs">Risk Score</span>
            </div>
            <p className="mt-2 text-lg font-semibold text-foreground">
              {project.riskScore}%
            </p>
          </div>
          <div className="rounded-lg bg-secondary p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span className="text-xs">Investors</span>
            </div>
            <p className="mt-2 text-lg font-semibold text-foreground">127</p>
          </div>
          <div className="rounded-lg bg-secondary p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span className="text-xs">Days Left</span>
            </div>
            <p className="mt-2 text-lg font-semibold text-foreground">
              {project.daysLeft}
            </p>
          </div>
        </div>

        <div className="mt-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Funding Progress</span>
            <span className="font-medium text-foreground">
              {fundingProgress.toFixed(1)}%
            </span>
          </div>
          <Progress value={fundingProgress} className="mt-2 h-3" />
          <p className="mt-1 text-xs text-muted-foreground">
            ${project.fundingRaised.toLocaleString()} raised of $
            {project.fundingGoal.toLocaleString()}
          </p>
        </div>

        <Tabs defaultValue="milestones" className="mt-6">
          <TabsList className="grid w-full grid-cols-3 bg-secondary">
            <TabsTrigger value="milestones">Milestones</TabsTrigger>
            <TabsTrigger value="ai-analysis">AI Analysis</TabsTrigger>
            <TabsTrigger value="team">Team & Docs</TabsTrigger>
          </TabsList>
          <TabsContent value="milestones" className="mt-4">
            <MilestoneTimeline />
          </TabsContent>
          <TabsContent value="ai-analysis" className="mt-4">
            <AIRiskPanel project={project} />
          </TabsContent>
          <TabsContent value="team" className="mt-4">
            <div className="space-y-4">
              <div className="rounded-lg border border-border bg-background p-4">
                <h4 className="font-medium text-foreground">Team Members</h4>
                <div className="mt-4 space-y-3">
                  {[
                    { name: "John Smith", role: "CEO & Founder", exp: "10+ years" },
                    { name: "Emily Chen", role: "CTO", exp: "8 years" },
                    { name: "Michael Brown", role: "Lead Developer", exp: "6 years" },
                  ].map((member) => (
                    <div
                      key={member.name}
                      className="flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-primary/20" />
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {member.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {member.role}
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {member.exp}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-lg border border-border bg-background p-4">
                <h4 className="font-medium text-foreground">Documentation</h4>
                <div className="mt-4 space-y-2">
                  {[
                    { name: "Whitepaper", type: "PDF" },
                    { name: "Technical Spec", type: "PDF" },
                    { name: "Pitch Deck", type: "PPT" },
                  ].map((doc) => (
                    <button
                      key={doc.name}
                      className="flex w-full items-center justify-between rounded-lg bg-secondary p-3 transition-colors hover:bg-secondary/80"
                    >
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-primary" />
                        <span className="text-sm text-foreground">
                          {doc.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-[10px]">
                          {doc.type}
                        </Badge>
                        <ExternalLink className="h-3 w-3 text-muted-foreground" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-6 flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Close
          </Button>
          <Button
            onClick={() => {
              onClose()
              onInvest(project)
            }}
            className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <CheckCircle className="mr-2 h-4 w-4" />
            Invest Now
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
