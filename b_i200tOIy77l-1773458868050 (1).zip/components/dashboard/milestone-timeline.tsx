"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import {
  CheckCircle,
  Clock,
  Circle,
  FileText,
  DollarSign,
  Upload,
} from "lucide-react"

interface Milestone {
  id: string
  title: string
  description: string
  amount: number
  status: "completed" | "in-progress" | "pending" | "locked"
  dueDate: string
  proofUploaded?: boolean
}

const mockMilestones: Milestone[] = [
  {
    id: "1",
    title: "Project Initialization",
    description: "Team formation, documentation, and initial planning",
    amount: 10000,
    status: "completed",
    dueDate: "2024-02-15",
    proofUploaded: true,
  },
  {
    id: "2",
    title: "MVP Development",
    description: "Core features implementation and internal testing",
    amount: 25000,
    status: "completed",
    dueDate: "2024-03-01",
    proofUploaded: true,
  },
  {
    id: "3",
    title: "Beta Launch",
    description: "Public beta release with user feedback collection",
    amount: 50000,
    status: "in-progress",
    dueDate: "2024-03-20",
    proofUploaded: false,
  },
  {
    id: "4",
    title: "Full Product Launch",
    description: "Production release with marketing campaign",
    amount: 75000,
    status: "pending",
    dueDate: "2024-04-15",
  },
  {
    id: "5",
    title: "Scale & Optimization",
    description: "Performance optimization and user acquisition",
    amount: 40000,
    status: "locked",
    dueDate: "2024-05-01",
  },
]

interface MilestoneTimelineProps {
  isFounder?: boolean
  onUploadProof?: (milestone: Milestone) => void
}

export function MilestoneTimeline({
  isFounder = false,
  onUploadProof,
}: MilestoneTimelineProps) {
  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base text-foreground">
            <FileText className="h-5 w-5 text-primary" />
            Milestone Timeline
          </CardTitle>
          <Badge variant="outline" className="text-xs text-muted-foreground">
            2 of 5 Completed
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          {mockMilestones.map((milestone, index) => (
            <div key={milestone.id} className="relative flex gap-4 pb-8 last:pb-0">
              {index < mockMilestones.length - 1 && (
                <div
                  className={cn(
                    "absolute left-[15px] top-8 h-full w-0.5",
                    milestone.status === "completed"
                      ? "bg-primary"
                      : "bg-border"
                  )}
                />
              )}
              <div
                className={cn(
                  "relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
                  milestone.status === "completed"
                    ? "bg-primary text-primary-foreground"
                    : milestone.status === "in-progress"
                      ? "bg-warning text-background"
                      : "bg-secondary text-muted-foreground"
                )}
              >
                {milestone.status === "completed" ? (
                  <CheckCircle className="h-4 w-4" />
                ) : milestone.status === "in-progress" ? (
                  <Clock className="h-4 w-4" />
                ) : (
                  <Circle className="h-4 w-4" />
                )}
              </div>
              <div className="flex-1 rounded-lg border border-border bg-background p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-medium text-foreground">
                      {milestone.title}
                    </h4>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {milestone.description}
                    </p>
                  </div>
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-xs",
                      milestone.status === "completed"
                        ? "border-success/50 text-success"
                        : milestone.status === "in-progress"
                          ? "border-warning/50 text-warning"
                          : "border-border text-muted-foreground"
                    )}
                  >
                    {milestone.status === "completed"
                      ? "Verified"
                      : milestone.status === "in-progress"
                        ? "In Progress"
                        : milestone.status === "pending"
                          ? "Pending"
                          : "Locked"}
                  </Badge>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-3 w-3" />$
                      {milestone.amount.toLocaleString()}
                    </span>
                    <span>Due: {milestone.dueDate}</span>
                  </div>
                  {isFounder && milestone.status === "in-progress" && (
                    <Button
                      size="sm"
                      variant={milestone.proofUploaded ? "outline" : "default"}
                      className="h-7 text-xs"
                      onClick={() => onUploadProof?.(milestone)}
                    >
                      <Upload className="mr-1 h-3 w-3" />
                      {milestone.proofUploaded
                        ? "Update Proof"
                        : "Upload Proof"}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
