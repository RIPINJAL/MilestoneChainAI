"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Upload,
  FileText,
  Image,
  Video,
  Link2,
  CheckCircle,
  Clock,
  AlertCircle,
  Eye,
  Download,
  Trash2,
  Plus,
  ExternalLink,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface Milestone {
  id: string
  title: string
  description: string
  targetDate: string
  fundingAmount: number
  status: "pending" | "submitted" | "under_review" | "verified" | "rejected"
  proofs: Proof[]
}

interface Proof {
  id: string
  type: "document" | "image" | "video" | "link"
  name: string
  url: string
  uploadedAt: Date
  description: string
}

const mockMilestones: Milestone[] = [
  {
    id: "1",
    title: "MVP Development",
    description: "Complete minimum viable product with core features",
    targetDate: "2024-03-15",
    fundingAmount: 50000,
    status: "verified",
    proofs: [
      {
        id: "p1",
        type: "link",
        name: "Live Demo Link",
        url: "https://demo.neuraTech.ai",
        uploadedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
        description: "Live MVP demo environment",
      },
      {
        id: "p2",
        type: "document",
        name: "Technical Documentation.pdf",
        url: "#",
        uploadedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
        description: "Complete technical documentation and architecture",
      },
    ],
  },
  {
    id: "2",
    title: "User Testing Phase",
    description: "Conduct beta testing with 100 users",
    targetDate: "2024-04-01",
    fundingAmount: 30000,
    status: "under_review",
    proofs: [
      {
        id: "p3",
        type: "document",
        name: "User Testing Report.pdf",
        url: "#",
        uploadedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
        description: "Beta testing results and user feedback analysis",
      },
      {
        id: "p4",
        type: "video",
        name: "User Session Recordings",
        url: "#",
        uploadedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
        description: "Recorded user sessions during beta testing",
      },
    ],
  },
  {
    id: "3",
    title: "AI Model Training",
    description: "Train and deploy the AI prediction model",
    targetDate: "2024-05-01",
    fundingAmount: 40000,
    status: "pending",
    proofs: [],
  },
  {
    id: "4",
    title: "Market Launch",
    description: "Official product launch and marketing campaign",
    targetDate: "2024-06-15",
    fundingAmount: 30000,
    status: "pending",
    proofs: [],
  },
]

interface ProofSubmissionProps {
  isFounder?: boolean
}

export function ProofSubmission({ isFounder = true }: ProofSubmissionProps) {
  const [milestones, setMilestones] = useState<Milestone[]>(mockMilestones)
  const [selectedMilestone, setSelectedMilestone] = useState<Milestone | null>(null)
  const [showUploadDialog, setShowUploadDialog] = useState(false)
  const [showProofDialog, setShowProofDialog] = useState(false)
  const [selectedProof, setSelectedProof] = useState<Proof | null>(null)
  const [uploadForm, setUploadForm] = useState({
    type: "document" as "document" | "image" | "video" | "link",
    name: "",
    url: "",
    description: "",
  })
  const [isUploading, setIsUploading] = useState(false)

  const getStatusConfig = (status: Milestone["status"]) => {
    switch (status) {
      case "verified":
        return {
          label: "Verified",
          icon: CheckCircle,
          color: "bg-emerald-500/10 text-emerald-500",
        }
      case "under_review":
        return {
          label: "Under Review",
          icon: Clock,
          color: "bg-amber-500/10 text-amber-500",
        }
      case "submitted":
        return {
          label: "Submitted",
          icon: Clock,
          color: "bg-primary/10 text-primary",
        }
      case "rejected":
        return {
          label: "Rejected",
          icon: AlertCircle,
          color: "bg-destructive/10 text-destructive",
        }
      default:
        return {
          label: "Pending",
          icon: Clock,
          color: "bg-muted text-muted-foreground",
        }
    }
  }

  const getProofIcon = (type: Proof["type"]) => {
    switch (type) {
      case "document":
        return FileText
      case "image":
        return Image
      case "video":
        return Video
      case "link":
        return Link2
      default:
        return FileText
    }
  }

  const handleUploadProof = async () => {
    if (!selectedMilestone || !uploadForm.name) return

    setIsUploading(true)
    // Simulate upload
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const newProof: Proof = {
      id: Date.now().toString(),
      type: uploadForm.type,
      name: uploadForm.name,
      url: uploadForm.url || "#",
      uploadedAt: new Date(),
      description: uploadForm.description,
    }

    setMilestones((prev) =>
      prev.map((m) =>
        m.id === selectedMilestone.id
          ? {
              ...m,
              proofs: [...m.proofs, newProof],
              status: m.status === "pending" ? "submitted" : m.status,
            }
          : m
      )
    )

    setUploadForm({ type: "document", name: "", url: "", description: "" })
    setShowUploadDialog(false)
    setIsUploading(false)
  }

  const handleDeleteProof = (milestoneId: string, proofId: string) => {
    setMilestones((prev) =>
      prev.map((m) =>
        m.id === milestoneId
          ? { ...m, proofs: m.proofs.filter((p) => p.id !== proofId) }
          : m
      )
    )
  }

  const completedMilestones = milestones.filter((m) => m.status === "verified").length
  const totalFunding = milestones.reduce((acc, m) => acc + m.fundingAmount, 0)
  const releasedFunding = milestones
    .filter((m) => m.status === "verified")
    .reduce((acc, m) => acc + m.fundingAmount, 0)

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Milestone Progress</p>
                <p className="mt-1 text-2xl font-bold text-foreground">
                  {completedMilestones}/{milestones.length}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <CheckCircle className="h-6 w-6 text-primary" />
              </div>
            </div>
            <Progress
              value={(completedMilestones / milestones.length) * 100}
              className="mt-4"
            />
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Funding Released</p>
                <p className="mt-1 text-2xl font-bold text-foreground">
                  ${releasedFunding.toLocaleString()}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/10">
                <CheckCircle className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
            <Progress value={(releasedFunding / totalFunding) * 100} className="mt-4" />
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Review</p>
                <p className="mt-1 text-2xl font-bold text-foreground">
                  {milestones.filter((m) => m.status === "under_review").length}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/10">
                <Clock className="h-6 w-6 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Milestones List */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5 text-primary" />
            Milestone Proof Submission
          </CardTitle>
          <CardDescription>
            {isFounder
              ? "Upload proofs to verify milestone completion and release funds"
              : "Review submitted proofs for milestone verification"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-4">
              {milestones.map((milestone, index) => {
                const statusConfig = getStatusConfig(milestone.status)
                const StatusIcon = statusConfig.icon
                return (
                  <div
                    key={milestone.id}
                    className="rounded-lg border border-border bg-secondary/30 p-4"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                          {index + 1}
                        </div>
                        <div>
                          <h3 className="font-medium text-foreground">
                            {milestone.title}
                          </h3>
                          <p className="mt-1 text-sm text-muted-foreground">
                            {milestone.description}
                          </p>
                          <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                            <span>Target: {milestone.targetDate}</span>
                            <span>|</span>
                            <span>
                              Funding: ${milestone.fundingAmount.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </div>
                      <Badge className={cn("shrink-0", statusConfig.color)}>
                        <StatusIcon className="mr-1 h-3 w-3" />
                        {statusConfig.label}
                      </Badge>
                    </div>

                    {/* Uploaded Proofs */}
                    {milestone.proofs.length > 0 && (
                      <div className="mt-4 space-y-2 border-t border-border pt-4">
                        <p className="text-xs font-medium text-muted-foreground">
                          Uploaded Proofs ({milestone.proofs.length})
                        </p>
                        <div className="grid gap-2 md:grid-cols-2">
                          {milestone.proofs.map((proof) => {
                            const ProofIcon = getProofIcon(proof.type)
                            return (
                              <div
                                key={proof.id}
                                className="flex items-center justify-between rounded-lg border border-border bg-card p-3"
                              >
                                <div className="flex items-center gap-3">
                                  <div className="flex h-8 w-8 items-center justify-center rounded bg-primary/10">
                                    <ProofIcon className="h-4 w-4 text-primary" />
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium text-foreground">
                                      {proof.name}
                                    </p>
                                    <p className="text-xs text-muted-foreground">
                                      {proof.uploadedAt.toLocaleDateString()}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-7 w-7"
                                    onClick={() => {
                                      setSelectedProof(proof)
                                      setShowProofDialog(true)
                                    }}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  {isFounder && milestone.status === "pending" && (
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7 text-destructive"
                                      onClick={() =>
                                        handleDeleteProof(milestone.id, proof.id)
                                      }
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )}

                    {/* Upload Button */}
                    {isFounder &&
                      (milestone.status === "pending" ||
                        milestone.status === "rejected") && (
                        <div className="mt-4 border-t border-border pt-4">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedMilestone(milestone)
                              setShowUploadDialog(true)
                            }}
                          >
                            <Plus className="mr-2 h-4 w-4" />
                            Add Proof
                          </Button>
                        </div>
                      )}
                  </div>
                )
              })}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Upload Proof Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Upload Proof</DialogTitle>
            <DialogDescription>
              Add evidence for: {selectedMilestone?.title}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Proof Type</Label>
              <Select
                value={uploadForm.type}
                onValueChange={(value: "document" | "image" | "video" | "link") =>
                  setUploadForm({ ...uploadForm, type: value })
                }
              >
                <SelectTrigger className="bg-secondary">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="document">Document (PDF, DOC)</SelectItem>
                  <SelectItem value="image">Image</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                  <SelectItem value="link">External Link</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Name</Label>
              <Input
                placeholder="e.g., Technical Documentation.pdf"
                value={uploadForm.name}
                onChange={(e) =>
                  setUploadForm({ ...uploadForm, name: e.target.value })
                }
                className="bg-secondary"
              />
            </div>
            {uploadForm.type === "link" && (
              <div className="space-y-2">
                <Label>URL</Label>
                <Input
                  placeholder="https://"
                  value={uploadForm.url}
                  onChange={(e) =>
                    setUploadForm({ ...uploadForm, url: e.target.value })
                  }
                  className="bg-secondary"
                />
              </div>
            )}
            {uploadForm.type !== "link" && (
              <div className="space-y-2">
                <Label>Upload File</Label>
                <div className="flex items-center justify-center rounded-lg border-2 border-dashed border-border bg-secondary/50 py-8">
                  <div className="text-center">
                    <Upload className="mx-auto h-8 w-8 text-muted-foreground" />
                    <p className="mt-2 text-sm text-muted-foreground">
                      Drag and drop or click to upload
                    </p>
                  </div>
                </div>
              </div>
            )}
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                placeholder="Describe what this proof demonstrates..."
                value={uploadForm.description}
                onChange={(e) =>
                  setUploadForm({ ...uploadForm, description: e.target.value })
                }
                className="bg-secondary"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleUploadProof} disabled={!uploadForm.name || isUploading}>
              {isUploading ? "Uploading..." : "Upload Proof"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Proof Dialog */}
      <Dialog open={showProofDialog} onOpenChange={setShowProofDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedProof && (() => {
                const ProofIcon = getProofIcon(selectedProof.type)
                return <ProofIcon className="h-5 w-5 text-primary" />
              })()}
              {selectedProof?.name}
            </DialogTitle>
            <DialogDescription>
              Uploaded on {selectedProof?.uploadedAt.toLocaleDateString()}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-muted-foreground">Description</Label>
              <p className="mt-1 text-sm text-foreground">
                {selectedProof?.description || "No description provided"}
              </p>
            </div>
            {selectedProof?.type === "link" && selectedProof?.url && (
              <div>
                <Label className="text-muted-foreground">Link</Label>
                <a
                  href={selectedProof.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1 flex items-center gap-2 text-sm text-primary hover:underline"
                >
                  {selectedProof.url}
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            )}
            {selectedProof?.type !== "link" && (
              <div className="flex items-center justify-center rounded-lg border border-border bg-secondary py-12">
                <div className="text-center text-muted-foreground">
                  <FileText className="mx-auto h-12 w-12" />
                  <p className="mt-2 text-sm">File preview not available</p>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowProofDialog(false)}>
              Close
            </Button>
            <Button>
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
