"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Receipt,
  Plus,
  FileText,
  DollarSign,
  TrendingUp,
  PieChart,
  Eye,
  Download,
  CheckCircle,
  Clock,
  AlertCircle,
  Building,
  Users,
  Server,
  Megaphone,
  FileCheck,
  ExternalLink,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface Expense {
  id: string
  category: "development" | "marketing" | "operations" | "salaries" | "infrastructure" | "other"
  description: string
  amount: number
  date: Date
  vendor: string
  invoiceUrl?: string
  status: "pending" | "verified" | "flagged"
  milestoneId: string
  milestoneName: string
}

interface FundingRound {
  id: string
  milestoneName: string
  amountReceived: number
  date: Date
  expenses: Expense[]
  remainingBalance: number
  status: "active" | "complete" | "pending"
}

const mockFundingRounds: FundingRound[] = [
  {
    id: "1",
    milestoneName: "MVP Development",
    amountReceived: 50000,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30),
    remainingBalance: 5200,
    status: "complete",
    expenses: [
      {
        id: "e1",
        category: "development",
        description: "Smart Contract Development - Solidity Developer",
        amount: 15000,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 25),
        vendor: "ChainCode Solutions",
        invoiceUrl: "#",
        status: "verified",
        milestoneId: "1",
        milestoneName: "MVP Development",
      },
      {
        id: "e2",
        category: "infrastructure",
        description: "AWS Cloud Services - 3 month subscription",
        amount: 4800,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 20),
        vendor: "Amazon Web Services",
        invoiceUrl: "#",
        status: "verified",
        milestoneId: "1",
        milestoneName: "MVP Development",
      },
      {
        id: "e3",
        category: "salaries",
        description: "Frontend Developer - Monthly Salary",
        amount: 8000,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15),
        vendor: "Internal",
        status: "verified",
        milestoneId: "1",
        milestoneName: "MVP Development",
      },
      {
        id: "e4",
        category: "development",
        description: "UI/UX Design Services",
        amount: 6000,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10),
        vendor: "DesignHub Agency",
        invoiceUrl: "#",
        status: "verified",
        milestoneId: "1",
        milestoneName: "MVP Development",
      },
      {
        id: "e5",
        category: "operations",
        description: "Legal Consultation - Token Compliance",
        amount: 3500,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8),
        vendor: "BlockLaw Firm",
        invoiceUrl: "#",
        status: "verified",
        milestoneId: "1",
        milestoneName: "MVP Development",
      },
      {
        id: "e6",
        category: "marketing",
        description: "Landing Page Development",
        amount: 2500,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
        vendor: "WebCraft Studio",
        invoiceUrl: "#",
        status: "verified",
        milestoneId: "1",
        milestoneName: "MVP Development",
      },
      {
        id: "e7",
        category: "other",
        description: "Software Licenses & Tools",
        amount: 5000,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
        vendor: "Various",
        status: "verified",
        milestoneId: "1",
        milestoneName: "MVP Development",
      },
    ],
  },
  {
    id: "2",
    milestoneName: "User Testing Phase",
    amountReceived: 30000,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
    remainingBalance: 18500,
    status: "active",
    expenses: [
      {
        id: "e8",
        category: "marketing",
        description: "User Acquisition Campaign",
        amount: 5000,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
        vendor: "GrowthHackers Inc",
        invoiceUrl: "#",
        status: "pending",
        milestoneId: "2",
        milestoneName: "User Testing Phase",
      },
      {
        id: "e9",
        category: "infrastructure",
        description: "Testing Environment Setup",
        amount: 2500,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
        vendor: "TestCloud Platform",
        invoiceUrl: "#",
        status: "pending",
        milestoneId: "2",
        milestoneName: "User Testing Phase",
      },
      {
        id: "e10",
        category: "operations",
        description: "Bug Bounty Program",
        amount: 4000,
        date: new Date(Date.now() - 1000 * 60 * 60 * 24),
        vendor: "HackerOne",
        status: "pending",
        milestoneId: "2",
        milestoneName: "User Testing Phase",
      },
    ],
  },
]

const categoryConfig = {
  development: {
    label: "Development",
    icon: Server,
    color: "bg-primary/10 text-primary",
  },
  marketing: {
    label: "Marketing",
    icon: Megaphone,
    color: "bg-pink-500/10 text-pink-500",
  },
  operations: {
    label: "Operations",
    icon: Building,
    color: "bg-amber-500/10 text-amber-500",
  },
  salaries: {
    label: "Salaries",
    icon: Users,
    color: "bg-emerald-500/10 text-emerald-500",
  },
  infrastructure: {
    label: "Infrastructure",
    icon: Server,
    color: "bg-blue-500/10 text-blue-500",
  },
  other: {
    label: "Other",
    icon: FileText,
    color: "bg-muted text-muted-foreground",
  },
}

interface ProofOfUtilizationProps {
  isFounder?: boolean
}

export function ProofOfUtilization({ isFounder = true }: ProofOfUtilizationProps) {
  const [fundingRounds] = useState<FundingRound[]>(mockFundingRounds)
  const [selectedRound, setSelectedRound] = useState<FundingRound>(fundingRounds[0])
  const [showAddExpenseDialog, setShowAddExpenseDialog] = useState(false)
  const [showExpenseDetailDialog, setShowExpenseDetailDialog] = useState(false)
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null)
  const [expenseForm, setExpenseForm] = useState({
    category: "development" as Expense["category"],
    description: "",
    amount: "",
    vendor: "",
    invoiceUrl: "",
  })

  const totalReceived = fundingRounds.reduce((acc, r) => acc + r.amountReceived, 0)
  const totalSpent = fundingRounds.reduce(
    (acc, r) => acc + r.expenses.reduce((sum, e) => sum + e.amount, 0),
    0
  )
  const totalRemaining = fundingRounds.reduce((acc, r) => acc + r.remainingBalance, 0)

  // Calculate category breakdown
  const categoryBreakdown = fundingRounds.flatMap((r) => r.expenses).reduce(
    (acc, expense) => {
      acc[expense.category] = (acc[expense.category] || 0) + expense.amount
      return acc
    },
    {} as Record<string, number>
  )

  const getStatusBadge = (status: Expense["status"]) => {
    switch (status) {
      case "verified":
        return (
          <Badge className="bg-emerald-500/10 text-emerald-500">
            <CheckCircle className="mr-1 h-3 w-3" />
            Verified
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-amber-500/10 text-amber-500">
            <Clock className="mr-1 h-3 w-3" />
            Pending
          </Badge>
        )
      case "flagged":
        return (
          <Badge className="bg-destructive/10 text-destructive">
            <AlertCircle className="mr-1 h-3 w-3" />
            Flagged
          </Badge>
        )
    }
  }

  const handleAddExpense = () => {
    // In real app, would add to database
    setShowAddExpenseDialog(false)
    setExpenseForm({
      category: "development",
      description: "",
      amount: "",
      vendor: "",
      invoiceUrl: "",
    })
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Received</p>
                <p className="mt-1 text-2xl font-bold text-foreground">
                  ${totalReceived.toLocaleString()}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/10">
                <DollarSign className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Spent</p>
                <p className="mt-1 text-2xl font-bold text-foreground">
                  ${totalSpent.toLocaleString()}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
            </div>
            <Progress value={(totalSpent / totalReceived) * 100} className="mt-4" />
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Remaining</p>
                <p className="mt-1 text-2xl font-bold text-foreground">
                  ${totalRemaining.toLocaleString()}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/10">
                <Receipt className="h-6 w-6 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Verified</p>
                <p className="mt-1 text-2xl font-bold text-foreground">
                  {Math.round(
                    (fundingRounds
                      .flatMap((r) => r.expenses)
                      .filter((e) => e.status === "verified").length /
                      fundingRounds.flatMap((r) => r.expenses).length) *
                      100
                  )}
                  %
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/10">
                <FileCheck className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Breakdown */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChart className="h-5 w-5 text-primary" />
            Spending by Category
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-3 lg:grid-cols-6">
            {Object.entries(categoryBreakdown).map(([category, amount]) => {
              const config = categoryConfig[category as keyof typeof categoryConfig]
              const Icon = config.icon
              const percentage = Math.round((amount / totalSpent) * 100)
              return (
                <div
                  key={category}
                  className="rounded-lg border border-border bg-secondary/30 p-4"
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={cn(
                        "flex h-8 w-8 items-center justify-center rounded-lg",
                        config.color
                      )}
                    >
                      <Icon className="h-4 w-4" />
                    </div>
                    <span className="text-sm font-medium text-foreground">
                      {config.label}
                    </span>
                  </div>
                  <p className="mt-2 text-lg font-bold text-foreground">
                    ${amount.toLocaleString()}
                  </p>
                  <p className="text-xs text-muted-foreground">{percentage}% of total</p>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Funding Rounds & Expenses */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Funding Rounds Selector */}
        <Card className="border-border bg-card lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Funding Rounds</CardTitle>
            <CardDescription>Select a milestone to view expenses</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {fundingRounds.map((round) => (
              <button
                key={round.id}
                onClick={() => setSelectedRound(round)}
                className={cn(
                  "flex w-full items-start gap-3 rounded-lg border border-border p-3 text-left transition-colors hover:bg-secondary",
                  selectedRound.id === round.id && "border-primary bg-secondary"
                )}
              >
                <div
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                    round.status === "complete"
                      ? "bg-emerald-500/10 text-emerald-500"
                      : round.status === "active"
                        ? "bg-primary/10 text-primary"
                        : "bg-muted text-muted-foreground"
                  )}
                >
                  {round.status === "complete" ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : (
                    <Clock className="h-5 w-5" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">
                    {round.milestoneName}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    ${round.amountReceived.toLocaleString()} received
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {round.expenses.length} expenses |{" "}
                    ${round.remainingBalance.toLocaleString()} remaining
                  </p>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        {/* Expenses Table */}
        <Card className="border-border bg-card lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">{selectedRound.milestoneName}</CardTitle>
              <CardDescription>
                ${selectedRound.amountReceived.toLocaleString()} received on{" "}
                {selectedRound.date.toLocaleDateString()}
              </CardDescription>
            </div>
            {isFounder && selectedRound.status === "active" && (
              <Button size="sm" onClick={() => setShowAddExpenseDialog(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Expense
              </Button>
            )}
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Category</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Vendor</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedRound.expenses.map((expense) => {
                    const config =
                      categoryConfig[expense.category as keyof typeof categoryConfig]
                    const Icon = config.icon
                    return (
                      <TableRow key={expense.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div
                              className={cn(
                                "flex h-7 w-7 items-center justify-center rounded",
                                config.color
                              )}
                            >
                              <Icon className="h-3.5 w-3.5" />
                            </div>
                            <span className="text-xs">{config.label}</span>
                          </div>
                        </TableCell>
                        <TableCell className="max-w-[200px]">
                          <p className="truncate text-sm">{expense.description}</p>
                          <p className="text-xs text-muted-foreground">
                            {expense.date.toLocaleDateString()}
                          </p>
                        </TableCell>
                        <TableCell className="text-sm">{expense.vendor}</TableCell>
                        <TableCell className="text-right font-medium">
                          ${expense.amount.toLocaleString()}
                        </TableCell>
                        <TableCell>{getStatusBadge(expense.status)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7"
                              onClick={() => {
                                setSelectedExpense(expense)
                                setShowExpenseDetailDialog(true)
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            {expense.invoiceUrl && (
                              <Button variant="ghost" size="icon" className="h-7 w-7">
                                <Download className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </ScrollArea>
            <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
              <span className="text-sm text-muted-foreground">
                Total: {selectedRound.expenses.length} expenses
              </span>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Total Spent</p>
                <p className="text-lg font-bold text-foreground">
                  $
                  {selectedRound.expenses
                    .reduce((acc, e) => acc + e.amount, 0)
                    .toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Expense Dialog */}
      <Dialog open={showAddExpenseDialog} onOpenChange={setShowAddExpenseDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Expense</DialogTitle>
            <DialogDescription>
              Record a new expense for {selectedRound.milestoneName}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Category</Label>
              <Select
                value={expenseForm.category}
                onValueChange={(value: Expense["category"]) =>
                  setExpenseForm({ ...expenseForm, category: value })
                }
              >
                <SelectTrigger className="bg-secondary">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(categoryConfig).map(([key, config]) => (
                    <SelectItem key={key} value={key}>
                      {config.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                placeholder="Describe the expense..."
                value={expenseForm.description}
                onChange={(e) =>
                  setExpenseForm({ ...expenseForm, description: e.target.value })
                }
                className="bg-secondary"
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Amount ($)</Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={expenseForm.amount}
                  onChange={(e) =>
                    setExpenseForm({ ...expenseForm, amount: e.target.value })
                  }
                  className="bg-secondary"
                />
              </div>
              <div className="space-y-2">
                <Label>Vendor</Label>
                <Input
                  placeholder="Company name"
                  value={expenseForm.vendor}
                  onChange={(e) =>
                    setExpenseForm({ ...expenseForm, vendor: e.target.value })
                  }
                  className="bg-secondary"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Invoice / Receipt (Optional)</Label>
              <div className="flex items-center justify-center rounded-lg border-2 border-dashed border-border bg-secondary/50 py-6">
                <div className="text-center">
                  <FileText className="mx-auto h-6 w-6 text-muted-foreground" />
                  <p className="mt-2 text-sm text-muted-foreground">
                    Drag and drop or click to upload
                  </p>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddExpenseDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddExpense}>Add Expense</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Expense Detail Dialog */}
      <Dialog open={showExpenseDetailDialog} onOpenChange={setShowExpenseDetailDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Expense Details</DialogTitle>
          </DialogHeader>
          {selectedExpense && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                {(() => {
                  const config =
                    categoryConfig[
                      selectedExpense.category as keyof typeof categoryConfig
                    ]
                  const Icon = config.icon
                  return (
                    <div
                      className={cn(
                        "flex h-10 w-10 items-center justify-center rounded-lg",
                        config.color
                      )}
                    >
                      <Icon className="h-5 w-5" />
                    </div>
                  )
                })()}
                <div>
                  <p className="font-medium text-foreground">
                    {
                      categoryConfig[
                        selectedExpense.category as keyof typeof categoryConfig
                      ].label
                    }
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {selectedExpense.date.toLocaleDateString()}
                  </p>
                </div>
                <div className="ml-auto">{getStatusBadge(selectedExpense.status)}</div>
              </div>
              <div className="space-y-3">
                <div>
                  <Label className="text-muted-foreground">Description</Label>
                  <p className="mt-1 text-sm text-foreground">
                    {selectedExpense.description}
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Amount</Label>
                    <p className="mt-1 text-lg font-bold text-foreground">
                      ${selectedExpense.amount.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Vendor</Label>
                    <p className="mt-1 text-sm text-foreground">
                      {selectedExpense.vendor}
                    </p>
                  </div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Milestone</Label>
                  <p className="mt-1 text-sm text-foreground">
                    {selectedExpense.milestoneName}
                  </p>
                </div>
                {selectedExpense.invoiceUrl && (
                  <div>
                    <Label className="text-muted-foreground">Invoice</Label>
                    <a
                      href={selectedExpense.invoiceUrl}
                      className="mt-1 flex items-center gap-2 text-sm text-primary hover:underline"
                    >
                      View Invoice
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowExpenseDetailDialog(false)}
            >
              Close
            </Button>
            {selectedExpense?.invoiceUrl && (
              <Button>
                <Download className="mr-2 h-4 w-4" />
                Download Invoice
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
