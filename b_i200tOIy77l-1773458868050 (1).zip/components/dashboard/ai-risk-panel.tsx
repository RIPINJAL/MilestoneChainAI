"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import {
  Brain,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
} from "lucide-react"
import type { Project } from "./project-card"

interface AIRiskPanelProps {
  project: Project | null
}

export function AIRiskPanel({ project }: AIRiskPanelProps) {
  if (!project) {
    return (
      <Card className="border-border bg-card">
        <CardContent className="flex h-64 items-center justify-center p-6">
          <div className="text-center">
            <Brain className="mx-auto h-12 w-12 text-muted-foreground" />
            <p className="mt-4 text-sm text-muted-foreground">
              Select a project to view AI risk analysis
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  const riskFactors = [
    {
      label: "Team Experience",
      score: 85,
      status: "low",
    },
    {
      label: "Market Viability",
      score: 72,
      status: "low",
    },
    {
      label: "Financial Health",
      score: 65,
      status: "medium",
    },
    {
      label: "Milestone History",
      score: 90,
      status: "low",
    },
  ]

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base text-foreground">
            <Brain className="h-5 w-5 text-primary" />
            AI Risk Analysis
          </CardTitle>
          <Badge
            variant="outline"
            className={cn(
              "text-xs",
              project.riskScore <= 30
                ? "border-success text-success"
                : project.riskScore <= 60
                  ? "border-warning text-warning"
                  : "border-destructive text-destructive"
            )}
          >
            {project.riskScore <= 30
              ? "Recommended"
              : project.riskScore <= 60
                ? "Moderate"
                : "Caution"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <div className="relative mx-auto h-32 w-32">
            <svg className="h-full w-full -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="currentColor"
                strokeWidth="8"
                className="text-secondary"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="currentColor"
                strokeWidth="8"
                strokeDasharray={`${project.confidence * 2.83} 283`}
                className="text-primary"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-foreground">
                {project.confidence}%
              </span>
              <span className="text-xs text-muted-foreground">Confidence</span>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {riskFactors.map((factor) => (
            <div key={factor.label}>
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{factor.label}</span>
                <span
                  className={cn(
                    "font-medium",
                    factor.status === "low"
                      ? "text-success"
                      : factor.status === "medium"
                        ? "text-warning"
                        : "text-destructive"
                  )}
                >
                  {factor.score}%
                </span>
              </div>
              <Progress value={factor.score} className="h-1.5" />
            </div>
          ))}
        </div>

        <div className="space-y-2 rounded-lg bg-secondary p-4">
          <h4 className="text-sm font-medium text-foreground">
            AI Recommendation
          </h4>
          <div className="flex items-start gap-2">
            {project.riskScore <= 30 ? (
              <>
                <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                <p className="text-xs text-muted-foreground">
                  Strong investment opportunity. Team has proven track record
                  with 90% milestone completion rate across previous projects.
                </p>
              </>
            ) : project.riskScore <= 60 ? (
              <>
                <Clock className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
                <p className="text-xs text-muted-foreground">
                  Moderate risk profile. Consider starting with smaller
                  milestone investments to evaluate team execution.
                </p>
              </>
            ) : (
              <>
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                <p className="text-xs text-muted-foreground">
                  Higher risk investment. Limited historical data available.
                  Proceed with caution and monitor closely.
                </p>
              </>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            Expected ROI: 18-24%
          </span>
          <span>Updated: 2 min ago</span>
        </div>
      </CardContent>
    </Card>
  )
}
