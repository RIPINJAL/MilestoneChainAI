"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp } from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const portfolioData = [
  { month: "Jan", value: 10000 },
  { month: "Feb", value: 12500 },
  { month: "Mar", value: 11800 },
  { month: "Apr", value: 15200 },
  { month: "May", value: 18500 },
  { month: "Jun", value: 22000 },
  { month: "Jul", value: 25800 },
]

const allocationData = [
  { name: "Tech", value: 45, color: "hsl(180, 60%, 50%)" },
  { name: "Healthcare", value: 25, color: "hsl(280, 60%, 55%)" },
  { name: "Green Energy", value: 20, color: "hsl(145, 60%, 50%)" },
  { name: "Fintech", value: 10, color: "hsl(60, 60%, 50%)" },
]

export function PortfolioChart() {
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card className="border-border bg-card">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-foreground">
            <TrendingUp className="h-5 w-5 text-primary" />
            Portfolio Growth
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={portfolioData}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop
                    offset="5%"
                    stopColor="hsl(180, 60%, 50%)"
                    stopOpacity={0.3}
                  />
                  <stop
                    offset="95%"
                    stopColor="hsl(180, 60%, 50%)"
                    stopOpacity={0}
                  />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(260, 10%, 28%)"
                vertical={false}
              />
              <XAxis
                dataKey="month"
                stroke="hsl(260, 10%, 65%)"
                tick={{ fill: "hsl(260, 10%, 65%)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                stroke="hsl(260, 10%, 65%)"
                tick={{ fill: "hsl(260, 10%, 65%)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(value) => `$${value / 1000}k`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(260, 10%, 16%)",
                  border: "1px solid hsl(260, 10%, 28%)",
                  borderRadius: "8px",
                  color: "hsl(0, 0%, 98%)",
                }}
                formatter={(value: number) => [
                  `$${value.toLocaleString()}`,
                  "Portfolio Value",
                ]}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke="hsl(180, 60%, 50%)"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorValue)"
              />
            </AreaChart>
          </ResponsiveContainer>
          <div className="mt-4 flex items-center justify-center gap-2 text-sm">
            <span className="text-success">+158%</span>
            <span className="text-muted-foreground">
              growth over 7 months
            </span>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border bg-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-base text-foreground">
            Investment Allocation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={allocationData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={4}
                dataKey="value"
              >
                {allocationData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(260, 10%, 16%)",
                  border: "1px solid hsl(260, 10%, 28%)",
                  borderRadius: "8px",
                  color: "hsl(0, 0%, 98%)",
                }}
                formatter={(value: number) => [`${value}%`, "Allocation"]}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {allocationData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div
                  className="h-3 w-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-xs text-muted-foreground">
                  {item.name}
                </span>
                <span className="ml-auto text-xs font-medium text-foreground">
                  {item.value}%
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
