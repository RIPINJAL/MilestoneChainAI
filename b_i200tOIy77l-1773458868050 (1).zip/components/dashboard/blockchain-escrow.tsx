"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import {
  Lock,
  Unlock,
  ArrowRight,
  CheckCircle,
  Clock,
  AlertCircle,
} from "lucide-react"

interface Transaction {
  id: string
  type: "lock" | "release" | "refund"
  amount: number
  milestone: string
  status: "completed" | "pending" | "failed"
  timestamp: string
  txHash: string
}

const mockTransactions: Transaction[] = [
  {
    id: "1",
    type: "lock",
    amount: 25000,
    milestone: "MVP Development",
    status: "completed",
    timestamp: "2024-03-10 14:32:21",
    txHash: "0x1a2b3c...4d5e6f",
  },
  {
    id: "2",
    type: "release",
    amount: 25000,
    milestone: "MVP Development",
    status: "completed",
    timestamp: "2024-03-12 09:15:43",
    txHash: "0x7g8h9i...0j1k2l",
  },
  {
    id: "3",
    type: "lock",
    amount: 50000,
    milestone: "Beta Launch",
    status: "completed",
    timestamp: "2024-03-13 11:22:18",
    txHash: "0x3m4n5o...6p7q8r",
  },
  {
    id: "4",
    type: "release",
    amount: 50000,
    milestone: "Beta Launch",
    status: "pending",
    timestamp: "Pending verification",
    txHash: "---",
  },
]

export function BlockchainEscrow() {
  const totalLocked = 75000
  const totalReleased = 25000

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-base text-foreground">
          <Lock className="h-5 w-5 text-primary" />
          Blockchain Escrow
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-lg bg-secondary p-4">
            <div className="flex items-center gap-2">
              <Lock className="h-4 w-4 text-warning" />
              <span className="text-xs text-muted-foreground">
                Locked in Escrow
              </span>
            </div>
            <p className="mt-2 text-xl font-semibold text-foreground">
              ${totalLocked.toLocaleString()}
            </p>
          </div>
          <div className="rounded-lg bg-secondary p-4">
            <div className="flex items-center gap-2">
              <Unlock className="h-4 w-4 text-success" />
              <span className="text-xs text-muted-foreground">
                Released to Founders
              </span>
            </div>
            <p className="mt-2 text-xl font-semibold text-foreground">
              ${totalReleased.toLocaleString()}
            </p>
          </div>
        </div>

        <div>
          <h4 className="mb-3 text-sm font-medium text-foreground">
            Recent Transactions
          </h4>
          <div className="space-y-3">
            {mockTransactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center gap-3 rounded-lg border border-border bg-background p-3"
              >
                <div
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-full",
                    tx.type === "lock"
                      ? "bg-warning/20 text-warning"
                      : tx.type === "release"
                        ? "bg-success/20 text-success"
                        : "bg-destructive/20 text-destructive"
                  )}
                >
                  {tx.type === "lock" ? (
                    <Lock className="h-4 w-4" />
                  ) : tx.type === "release" ? (
                    <Unlock className="h-4 w-4" />
                  ) : (
                    <ArrowRight className="h-4 w-4" />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-foreground">
                      {tx.type === "lock"
                        ? "Funds Locked"
                        : tx.type === "release"
                          ? "Funds Released"
                          : "Funds Refunded"}
                    </span>
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[10px]",
                        tx.status === "completed"
                          ? "border-success/50 text-success"
                          : tx.status === "pending"
                            ? "border-warning/50 text-warning"
                            : "border-destructive/50 text-destructive"
                      )}
                    >
                      {tx.status === "completed" ? (
                        <CheckCircle className="mr-1 h-2.5 w-2.5" />
                      ) : tx.status === "pending" ? (
                        <Clock className="mr-1 h-2.5 w-2.5" />
                      ) : (
                        <AlertCircle className="mr-1 h-2.5 w-2.5" />
                      )}
                      {tx.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {tx.milestone}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">
                    ${tx.amount.toLocaleString()}
                  </p>
                  <p className="font-mono text-[10px] text-muted-foreground">
                    {tx.txHash}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-lg border border-primary/30 bg-primary/10 p-3">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-primary" />
            <span className="text-xs font-medium text-primary">
              Smart Contract Secured
            </span>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            All funds are secured by verified smart contracts on the blockchain.
            Automatic release upon milestone verification.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
