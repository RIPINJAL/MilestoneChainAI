"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Wallet,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  CreditCard,
  CheckCircle,
} from "lucide-react"

interface WalletPanelProps {
  balance: number
  setBalance: (balance: number) => void
}

export function WalletPanel({ balance, setBalance }: WalletPanelProps) {
  const [isAddFundsOpen, setIsAddFundsOpen] = useState(false)
  const [addAmount, setAddAmount] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleAddFunds = async () => {
    const amount = parseFloat(addAmount)
    if (isNaN(amount) || amount <= 0) return

    setIsProcessing(true)
    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setBalance(balance + amount)
    setIsProcessing(false)
    setIsSuccess(true)
    
    setTimeout(() => {
      setIsSuccess(false)
      setIsAddFundsOpen(false)
      setAddAmount("")
    }, 1500)
  }

  const transactions = [
    {
      id: "1",
      type: "deposit",
      amount: 10000,
      date: "2024-03-14",
      status: "completed",
    },
    {
      id: "2",
      type: "investment",
      amount: -5000,
      project: "EcoTrack",
      date: "2024-03-13",
      status: "completed",
    },
    {
      id: "3",
      type: "return",
      amount: 2500,
      project: "NeuraTech",
      date: "2024-03-12",
      status: "completed",
    },
    {
      id: "4",
      type: "investment",
      amount: -7500,
      project: "HealthSync",
      date: "2024-03-11",
      status: "completed",
    },
  ]

  return (
    <div className="space-y-6">
      <Card className="border-border bg-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Available Balance</p>
              <p className="mt-1 text-3xl font-bold text-foreground">
                ${balance.toLocaleString()}
              </p>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20">
              <Wallet className="h-6 w-6 text-primary" />
            </div>
          </div>
          <div className="mt-6 flex gap-3">
            <Dialog open={isAddFundsOpen} onOpenChange={setIsAddFundsOpen}>
              <DialogTrigger asChild>
                <Button className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Funds
                </Button>
              </DialogTrigger>
              <DialogContent className="border-border bg-card">
                <DialogHeader>
                  <DialogTitle className="text-foreground">Add Funds</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  {isSuccess ? (
                    <div className="flex flex-col items-center py-8">
                      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-success/20">
                        <CheckCircle className="h-8 w-8 text-success" />
                      </div>
                      <p className="mt-4 text-lg font-semibold text-foreground">
                        Payment Successful!
                      </p>
                      <p className="text-sm text-muted-foreground">
                        ${parseFloat(addAmount).toLocaleString()} added to your
                        wallet
                      </p>
                    </div>
                  ) : (
                    <>
                      <div>
                        <label className="text-sm text-muted-foreground">
                          Amount (USD)
                        </label>
                        <Input
                          type="number"
                          placeholder="Enter amount"
                          value={addAmount}
                          onChange={(e) => setAddAmount(e.target.value)}
                          className="mt-2 border-border bg-background text-foreground"
                        />
                      </div>
                      <div className="flex gap-2">
                        {[100, 500, 1000, 5000].map((amount) => (
                          <Button
                            key={amount}
                            variant="outline"
                            size="sm"
                            onClick={() => setAddAmount(amount.toString())}
                            className="flex-1 text-xs"
                          >
                            ${amount}
                          </Button>
                        ))}
                      </div>
                      <div className="rounded-lg border border-border bg-secondary p-4">
                        <div className="flex items-center gap-3">
                          <CreditCard className="h-8 w-8 text-primary" />
                          <div>
                            <p className="text-sm font-medium text-foreground">
                              Simulated Payment
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Test environment - no real charges
                            </p>
                          </div>
                        </div>
                      </div>
                      <Button
                        onClick={handleAddFunds}
                        disabled={isProcessing || !addAmount}
                        className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                      >
                        {isProcessing ? (
                          <>
                            <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                            Processing...
                          </>
                        ) : (
                          `Add $${addAmount || "0"}`
                        )}
                      </Button>
                    </>
                  )}
                </div>
              </DialogContent>
            </Dialog>
            <Button
              variant="outline"
              className="flex-1 border-border text-foreground"
            >
              <ArrowUpRight className="mr-2 h-4 w-4" />
              Withdraw
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border bg-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-base text-foreground">
            Recent Transactions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {transactions.map((tx) => (
            <div
              key={tx.id}
              className="flex items-center justify-between rounded-lg border border-border bg-background p-3"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-8 w-8 items-center justify-center rounded-full ${
                    tx.amount > 0
                      ? "bg-success/20 text-success"
                      : "bg-warning/20 text-warning"
                  }`}
                >
                  {tx.amount > 0 ? (
                    <ArrowDownLeft className="h-4 w-4" />
                  ) : (
                    <ArrowUpRight className="h-4 w-4" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground capitalize">
                    {tx.type}
                    {tx.project && ` - ${tx.project}`}
                  </p>
                  <p className="text-xs text-muted-foreground">{tx.date}</p>
                </div>
              </div>
              <div className="text-right">
                <p
                  className={`text-sm font-medium ${
                    tx.amount > 0 ? "text-success" : "text-foreground"
                  }`}
                >
                  {tx.amount > 0 ? "+" : ""}${Math.abs(tx.amount).toLocaleString()}
                </p>
                <Badge
                  variant="outline"
                  className="text-[10px] text-muted-foreground"
                >
                  {tx.status}
                </Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
