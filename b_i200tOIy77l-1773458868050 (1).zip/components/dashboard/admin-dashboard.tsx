"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Users,
  Briefcase,
  FileCheck,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Search,
  MoreVertical,
  CheckCircle,
  XCircle,
  Eye,
  Clock,
  Shield,
  Ban,
  MessageSquare,
  Activity,
  Filter,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface User {
  id: string
  name: string
  email: string
  role: "founder" | "investor"
  status: "active" | "suspended" | "pending"
  joinedDate: Date
  projectsCount?: number
  investmentsCount?: number
  totalInvested?: number
  totalRaised?: number
}

interface MilestoneReview {
  id: string
  projectName: string
  milestoneName: string
  founderName: string
  submittedDate: Date
  amount: number
  proofCount: number
  status: "pending" | "approved" | "rejected"
  aiScore: number
}

interface Transaction {
  id: string
  type: "investment" | "release" | "refund"
  projectName: string
  fromUser: string
  toUser: string
  amount: number
  date: Date
  status: "completed" | "pending" | "failed"
}

const mockUsers: User[] = [
  {
    id: "1",
    name: "Sarah Johnson",
    email: "sarah@ecotrack.io",
    role: "founder",
    status: "active",
    joinedDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 120),
    projectsCount: 2,
    totalRaised: 180000,
  },
  {
    id: "2",
    name: "Alex Chen",
    email: "alex.chen@capital.vc",
    role: "investor",
    status: "active",
    joinedDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 90),
    investmentsCount: 8,
    totalInvested: 125000,
  },
  {
    id: "3",
    name: "Michael Park",
    email: "m.park@ventures.com",
    role: "investor",
    status: "active",
    joinedDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 60),
    investmentsCount: 5,
    totalInvested: 75000,
  },
  {
    id: "4",
    name: "Emma Wilson",
    email: "emma@healthsync.med",
    role: "founder",
    status: "pending",
    joinedDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
    projectsCount: 1,
    totalRaised: 0,
  },
  {
    id: "5",
    name: "James Lee",
    email: "james@finflow.io",
    role: "founder",
    status: "suspended",
    joinedDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 200),
    projectsCount: 1,
    totalRaised: 650000,
  },
]

const mockMilestoneReviews: MilestoneReview[] = [
  {
    id: "1",
    projectName: "NeuraTech AI",
    milestoneName: "AI Model Training Complete",
    founderName: "Sarah Johnson",
    submittedDate: new Date(Date.now() - 1000 * 60 * 60 * 2),
    amount: 40000,
    proofCount: 4,
    status: "pending",
    aiScore: 87,
  },
  {
    id: "2",
    projectName: "EcoTrack",
    milestoneName: "Beta Launch",
    founderName: "Michael Chen",
    submittedDate: new Date(Date.now() - 1000 * 60 * 60 * 8),
    amount: 30000,
    proofCount: 3,
    status: "pending",
    aiScore: 72,
  },
  {
    id: "3",
    projectName: "HealthSync",
    milestoneName: "Regulatory Approval",
    founderName: "Emma Wilson",
    submittedDate: new Date(Date.now() - 1000 * 60 * 60 * 24),
    amount: 50000,
    proofCount: 6,
    status: "pending",
    aiScore: 91,
  },
  {
    id: "4",
    projectName: "FinFlow",
    milestoneName: "MVP Development",
    founderName: "James Lee",
    submittedDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
    amount: 45000,
    proofCount: 2,
    status: "approved",
    aiScore: 95,
  },
]

const mockTransactions: Transaction[] = [
  {
    id: "1",
    type: "investment",
    projectName: "NeuraTech AI",
    fromUser: "Alex Chen",
    toUser: "Escrow",
    amount: 25000,
    date: new Date(Date.now() - 1000 * 60 * 60 * 1),
    status: "completed",
  },
  {
    id: "2",
    type: "release",
    projectName: "EcoTrack",
    fromUser: "Escrow",
    toUser: "Sarah Johnson",
    amount: 30000,
    date: new Date(Date.now() - 1000 * 60 * 60 * 4),
    status: "completed",
  },
  {
    id: "3",
    type: "investment",
    projectName: "HealthSync",
    fromUser: "Michael Park",
    toUser: "Escrow",
    amount: 15000,
    date: new Date(Date.now() - 1000 * 60 * 60 * 8),
    status: "pending",
  },
  {
    id: "4",
    type: "refund",
    projectName: "FinFlow",
    fromUser: "Escrow",
    toUser: "James Lee",
    amount: 10000,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24),
    status: "completed",
  },
]

export function AdminDashboard() {
  const [users] = useState<User[]>(mockUsers)
  const [milestoneReviews, setMilestoneReviews] = useState<MilestoneReview[]>(mockMilestoneReviews)
  const [transactions] = useState<Transaction[]>(mockTransactions)
  const [selectedReview, setSelectedReview] = useState<MilestoneReview | null>(null)
  const [showReviewDialog, setShowReviewDialog] = useState(false)
  const [reviewNotes, setReviewNotes] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  const pendingReviews = milestoneReviews.filter((r) => r.status === "pending").length
  const totalUsers = users.length
  const activeProjects = 12
  const totalEscrowValue = 2450000

  const handleApproveReview = (reviewId: string) => {
    setMilestoneReviews((prev) =>
      prev.map((r) => (r.id === reviewId ? { ...r, status: "approved" as const } : r))
    )
    setShowReviewDialog(false)
    setReviewNotes("")
  }

  const handleRejectReview = (reviewId: string) => {
    setMilestoneReviews((prev) =>
      prev.map((r) => (r.id === reviewId ? { ...r, status: "rejected" as const } : r))
    )
    setShowReviewDialog(false)
    setReviewNotes("")
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
      case "completed":
      case "approved":
        return (
          <Badge className="bg-emerald-500/10 text-emerald-500">
            <CheckCircle className="mr-1 h-3 w-3" />
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-amber-500/10 text-amber-500">
            <Clock className="mr-1 h-3 w-3" />
            Pending
          </Badge>
        )
      case "suspended":
      case "failed":
      case "rejected":
        return (
          <Badge className="bg-destructive/10 text-destructive">
            <XCircle className="mr-1 h-3 w-3" />
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const getAIScoreColor = (score: number) => {
    if (score >= 80) return "text-emerald-500"
    if (score >= 60) return "text-amber-500"
    return "text-destructive"
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Reviews</p>
                <p className="mt-1 text-2xl font-bold text-foreground">{pendingReviews}</p>
                <p className="text-xs text-amber-500">Requires attention</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/10">
                <FileCheck className="h-6 w-6 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Users</p>
                <p className="mt-1 text-2xl font-bold text-foreground">{totalUsers}</p>
                <p className="text-xs text-emerald-500">+12 this week</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Projects</p>
                <p className="mt-1 text-2xl font-bold text-foreground">{activeProjects}</p>
                <p className="text-xs text-muted-foreground">3 pending approval</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/10">
                <Briefcase className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total in Escrow</p>
                <p className="mt-1 text-2xl font-bold text-foreground">
                  ${(totalEscrowValue / 1000000).toFixed(2)}M
                </p>
                <p className="text-xs text-emerald-500">+$125K today</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="reviews" className="space-y-4">
        <TabsList className="bg-secondary">
          <TabsTrigger value="reviews" className="gap-2">
            <FileCheck className="h-4 w-4" />
            Milestone Reviews
            {pendingReviews > 0 && (
              <Badge className="ml-1 bg-amber-500 text-amber-950">{pendingReviews}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="users" className="gap-2">
            <Users className="h-4 w-4" />
            Users
          </TabsTrigger>
          <TabsTrigger value="transactions" className="gap-2">
            <Activity className="h-4 w-4" />
            Transactions
          </TabsTrigger>
        </TabsList>

        {/* Milestone Reviews Tab */}
        <TabsContent value="reviews">
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileCheck className="h-5 w-5 text-primary" />
                    Milestone Verification Queue
                  </CardTitle>
                  <CardDescription>
                    Review and verify milestone submissions from founders
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    <Filter className="mr-2 h-4 w-4" />
                    Filter
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Project</TableHead>
                      <TableHead>Milestone</TableHead>
                      <TableHead>Founder</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>AI Score</TableHead>
                      <TableHead>Proofs</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {milestoneReviews.map((review) => (
                      <TableRow key={review.id}>
                        <TableCell className="font-medium">{review.projectName}</TableCell>
                        <TableCell>
                          <div>
                            <p className="text-sm">{review.milestoneName}</p>
                            <p className="text-xs text-muted-foreground">
                              {review.submittedDate.toLocaleDateString()}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>{review.founderName}</TableCell>
                        <TableCell>${review.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Shield className={cn("h-4 w-4", getAIScoreColor(review.aiScore))} />
                            <span className={cn("font-medium", getAIScoreColor(review.aiScore))}>
                              {review.aiScore}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{review.proofCount} files</Badge>
                        </TableCell>
                        <TableCell>{getStatusBadge(review.status)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => {
                                setSelectedReview(review)
                                setShowReviewDialog(true)
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            {review.status === "pending" && (
                              <>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-emerald-500"
                                  onClick={() => handleApproveReview(review.id)}
                                >
                                  <CheckCircle className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-destructive"
                                  onClick={() => handleRejectReview(review.id)}
                                >
                                  <XCircle className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users">
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    User Management
                  </CardTitle>
                  <CardDescription>Manage founders and investors on the platform</CardDescription>
                </div>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search users..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-secondary pl-9"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead>Activity</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users
                      .filter(
                        (u) =>
                          u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          u.email.toLowerCase().includes(searchQuery.toLowerCase())
                      )
                      .map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium text-foreground">{user.name}</p>
                              <p className="text-xs text-muted-foreground">{user.email}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={cn(
                                user.role === "founder"
                                  ? "bg-emerald-500/10 text-emerald-500"
                                  : "bg-primary/10 text-primary"
                              )}
                            >
                              {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                            </Badge>
                          </TableCell>
                          <TableCell>{getStatusBadge(user.status)}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {user.joinedDate.toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            {user.role === "founder" ? (
                              <div className="text-sm">
                                <p>{user.projectsCount} projects</p>
                                <p className="text-muted-foreground">
                                  ${user.totalRaised?.toLocaleString()} raised
                                </p>
                              </div>
                            ) : (
                              <div className="text-sm">
                                <p>{user.investmentsCount} investments</p>
                                <p className="text-muted-foreground">
                                  ${user.totalInvested?.toLocaleString()} invested
                                </p>
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Profile
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <MessageSquare className="mr-2 h-4 w-4" />
                                  Send Message
                                </DropdownMenuItem>
                                {user.status === "pending" && (
                                  <DropdownMenuItem className="text-emerald-500">
                                    <CheckCircle className="mr-2 h-4 w-4" />
                                    Approve User
                                  </DropdownMenuItem>
                                )}
                                {user.status === "active" && (
                                  <DropdownMenuItem className="text-destructive">
                                    <Ban className="mr-2 h-4 w-4" />
                                    Suspend User
                                  </DropdownMenuItem>
                                )}
                                {user.status === "suspended" && (
                                  <DropdownMenuItem className="text-emerald-500">
                                    <CheckCircle className="mr-2 h-4 w-4" />
                                    Reactivate User
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Transactions Tab */}
        <TabsContent value="transactions">
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-primary" />
                    Transaction History
                  </CardTitle>
                  <CardDescription>Monitor all platform transactions</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Export Report
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Project</TableHead>
                      <TableHead>From</TableHead>
                      <TableHead>To</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell>
                          <Badge
                            className={cn(
                              tx.type === "investment"
                                ? "bg-primary/10 text-primary"
                                : tx.type === "release"
                                  ? "bg-emerald-500/10 text-emerald-500"
                                  : "bg-amber-500/10 text-amber-500"
                            )}
                          >
                            {tx.type.charAt(0).toUpperCase() + tx.type.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">{tx.projectName}</TableCell>
                        <TableCell>{tx.fromUser}</TableCell>
                        <TableCell>{tx.toUser}</TableCell>
                        <TableCell className="font-medium">${tx.amount.toLocaleString()}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {tx.date.toLocaleString()}
                        </TableCell>
                        <TableCell>{getStatusBadge(tx.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Review Detail Dialog */}
      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Review Milestone Submission</DialogTitle>
            <DialogDescription>
              {selectedReview?.projectName} - {selectedReview?.milestoneName}
            </DialogDescription>
          </DialogHeader>
          {selectedReview && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-lg bg-secondary p-3">
                  <p className="text-xs text-muted-foreground">Amount</p>
                  <p className="text-lg font-bold text-foreground">
                    ${selectedReview.amount.toLocaleString()}
                  </p>
                </div>
                <div className="rounded-lg bg-secondary p-3">
                  <p className="text-xs text-muted-foreground">AI Confidence</p>
                  <p className={cn("text-lg font-bold", getAIScoreColor(selectedReview.aiScore))}>
                    {selectedReview.aiScore}%
                  </p>
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Submitted Proofs</p>
                <div className="mt-2 space-y-2">
                  {Array.from({ length: selectedReview.proofCount }).map((_, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between rounded-lg border border-border bg-secondary/50 p-2"
                    >
                      <span className="text-sm">Proof Document {i + 1}</span>
                      <Button variant="ghost" size="sm">
                        <Eye className="mr-2 h-4 w-4" />
                        View
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Review Notes</Label>
                <Textarea
                  placeholder="Add notes about this review..."
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  className="bg-secondary"
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowReviewDialog(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => selectedReview && handleRejectReview(selectedReview.id)}
            >
              <XCircle className="mr-2 h-4 w-4" />
              Reject
            </Button>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700"
              onClick={() => selectedReview && handleApproveReview(selectedReview.id)}
            >
              <CheckCircle className="mr-2 h-4 w-4" />
              Approve & Release Funds
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
