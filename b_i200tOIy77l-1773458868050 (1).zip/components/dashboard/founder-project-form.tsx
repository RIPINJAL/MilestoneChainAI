"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Plus, Trash2, CheckCircle } from "lucide-react"

interface Milestone {
  id: string
  title: string
  description: string
  amount: string
  dueDate: string
}

export function FounderProjectForm() {
  const [projectName, setProjectName] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [milestones, setMilestones] = useState<Milestone[]>([
    { id: "1", title: "", description: "", amount: "", dueDate: "" },
  ])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const addMilestone = () => {
    setMilestones([
      ...milestones,
      {
        id: Date.now().toString(),
        title: "",
        description: "",
        amount: "",
        dueDate: "",
      },
    ])
  }

  const removeMilestone = (id: string) => {
    if (milestones.length > 1) {
      setMilestones(milestones.filter((m) => m.id !== id))
    }
  }

  const updateMilestone = (id: string, field: keyof Milestone, value: string) => {
    setMilestones(
      milestones.map((m) => (m.id === id ? { ...m, [field]: value } : m))
    )
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsSubmitting(false)
    setIsSuccess(true)
    setTimeout(() => {
      setIsSuccess(false)
      setProjectName("")
      setDescription("")
      setCategory("")
      setMilestones([
        { id: "1", title: "", description: "", amount: "", dueDate: "" },
      ])
    }, 3000)
  }

  const totalFunding = milestones.reduce(
    (sum, m) => sum + (parseFloat(m.amount) || 0),
    0
  )

  if (isSuccess) {
    return (
      <Card className="border-border bg-card">
        <CardContent className="flex flex-col items-center py-16">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-success/20">
            <CheckCircle className="h-10 w-10 text-success" />
          </div>
          <h3 className="mt-6 text-xl font-semibold text-foreground">
            Project Submitted!
          </h3>
          <p className="mt-2 text-center text-sm text-muted-foreground">
            Your project is now under review. You'll receive a notification once
            it's approved for funding.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="text-foreground">Create New Project</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="text-sm text-muted-foreground">Project Name</label>
            <Input
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="Enter project name"
              className="mt-2 border-border bg-background text-foreground"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground">Category</label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="mt-2 border-border bg-background text-foreground">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent className="border-border bg-card">
                <SelectItem value="tech">Technology</SelectItem>
                <SelectItem value="healthcare">Healthcare</SelectItem>
                <SelectItem value="fintech">Fintech</SelectItem>
                <SelectItem value="green">Green Energy</SelectItem>
                <SelectItem value="ai">AI/ML</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <label className="text-sm text-muted-foreground">Description</label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe your project..."
            className="mt-2 min-h-[100px] border-border bg-background text-foreground"
          />
        </div>

        <div>
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-foreground">
              Milestones
            </label>
            <span className="text-sm text-muted-foreground">
              Total: ${totalFunding.toLocaleString()}
            </span>
          </div>
          <div className="mt-4 space-y-4">
            {milestones.map((milestone, index) => (
              <div
                key={milestone.id}
                className="rounded-lg border border-border bg-background p-4"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    Milestone {index + 1}
                  </span>
                  {milestones.length > 1 && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeMilestone(milestone.id)}
                      className="h-8 w-8 text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <div className="mt-4 grid gap-4 md:grid-cols-2">
                  <Input
                    value={milestone.title}
                    onChange={(e) =>
                      updateMilestone(milestone.id, "title", e.target.value)
                    }
                    placeholder="Milestone title"
                    className="border-border bg-secondary text-foreground"
                  />
                  <Input
                    value={milestone.dueDate}
                    onChange={(e) =>
                      updateMilestone(milestone.id, "dueDate", e.target.value)
                    }
                    type="date"
                    className="border-border bg-secondary text-foreground"
                  />
                </div>
                <div className="mt-4 grid gap-4 md:grid-cols-2">
                  <Input
                    value={milestone.description}
                    onChange={(e) =>
                      updateMilestone(milestone.id, "description", e.target.value)
                    }
                    placeholder="Description"
                    className="border-border bg-secondary text-foreground"
                  />
                  <Input
                    value={milestone.amount}
                    onChange={(e) =>
                      updateMilestone(milestone.id, "amount", e.target.value)
                    }
                    type="number"
                    placeholder="Funding amount ($)"
                    className="border-border bg-secondary text-foreground"
                  />
                </div>
              </div>
            ))}
          </div>
          <Button
            variant="outline"
            onClick={addMilestone}
            className="mt-4 w-full border-dashed"
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Milestone
          </Button>
        </div>

        <Button
          onClick={handleSubmit}
          disabled={isSubmitting || !projectName || !description || !category}
          className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
        >
          {isSubmitting ? (
            <>
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
              Submitting...
            </>
          ) : (
            "Submit Project for Review"
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
