"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Bell, Search, Wallet } from "lucide-react"

interface HeaderProps {
  walletBalance: number
  userRole: "investor" | "founder"
}

export function Header({ walletBalance, userRole }: HeaderProps) {
  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-card px-6">
      <div className="flex items-center gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search projects, milestones..."
            className="w-80 border-border bg-background pl-10 text-foreground placeholder:text-muted-foreground"
          />
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 rounded-lg bg-secondary px-4 py-2">
          <Wallet className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-foreground">
            ${walletBalance.toLocaleString()}
          </span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="relative text-muted-foreground hover:text-foreground"
        >
          <Bell className="h-5 w-5" />
          <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">
            3
          </span>
        </Button>
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full bg-primary/20" />
          <div className="hidden lg:block">
            <p className="text-sm font-medium text-foreground">
              {userRole === "investor" ? "Alex Chen" : "Sarah Parker"}
            </p>
            <Badge variant="outline" className="text-[10px] capitalize text-muted-foreground">
              {userRole}
            </Badge>
          </div>
        </div>
      </div>
    </header>
  )
}
