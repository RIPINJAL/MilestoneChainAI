"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import { TrendingUp, Shield, Clock, DollarSign } from "lucide-react"

export interface Project {
  id: string
  name: string
  description: string
  category: string
  fundingGoal: number
  fundingRaised: number
  milestones: number
  completedMilestones: number
  riskScore: number
  confidence: number
  daysLeft: number
  status: "active" | "completed" | "pending"
}

interface ProjectCardProps {
  project: Project
  onInvest?: (project: Project) => void
  onViewDetails?: (project: Project) => void
}

function getRiskColor(score: number) {
  if (score <= 30) return "text-success"
  if (score <= 60) return "text-warning"
  return "text-destructive"
}

function getRiskLabel(score: number) {
  if (score <= 30) return "Low Risk"
  if (score <= 60) return "Medium Risk"
  return "High Risk"
}

export function ProjectCard({
  project,
  onInvest,
  onViewDetails,
}: ProjectCardProps) {
  const fundingProgress = (project.fundingRaised / project.fundingGoal) * 100
  const milestoneProgress =
    (project.completedMilestones / project.milestones) * 100

  return (
    <Card className="group border-border bg-card transition-all hover:border-primary/50">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-foreground">{project.name}</h3>
              <Badge
                variant="outline"
                className="border-border text-xs text-muted-foreground"
              >
                {project.category}
              </Badge>
            </div>
            <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
              {project.description}
            </p>
          </div>
          <div
            className={cn(
              "ml-4 flex flex-col items-center rounded-lg bg-secondary p-3",
              getRiskColor(project.riskScore)
            )}
          >
            <Shield className="h-5 w-5" />
            <span className="mt-1 text-xs font-medium">
              {project.riskScore}%
            </span>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <DollarSign className="h-3 w-3" />
              <span>Funding Progress</span>
            </div>
            <Progress value={fundingProgress} className="mt-2 h-2" />
            <p className="mt-1 text-xs text-muted-foreground">
              ${project.fundingRaised.toLocaleString()} /{" "}
              ${project.fundingGoal.toLocaleString()}
            </p>
          </div>
          <div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <TrendingUp className="h-3 w-3" />
              <span>Milestones</span>
            </div>
            <Progress value={milestoneProgress} className="mt-2 h-2" />
            <p className="mt-1 text-xs text-muted-foreground">
              {project.completedMilestones} / {project.milestones} completed
            </p>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span className={cn("font-medium", getRiskColor(project.riskScore))}>
              {getRiskLabel(project.riskScore)}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {project.daysLeft} days left
            </span>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onViewDetails?.(project)}
              className="text-xs"
            >
              Details
            </Button>
            <Button
              size="sm"
              onClick={() => onInvest?.(project)}
              className="bg-primary text-primary-foreground text-xs hover:bg-primary/90"
            >
              Invest
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
