"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { StatsCard } from "@/components/dashboard/stats-card"
import { ProjectCard, type Project } from "@/components/dashboard/project-card"
import { AIRiskPanel } from "@/components/dashboard/ai-risk-panel"
import { BlockchainEscrow } from "@/components/dashboard/blockchain-escrow"
import { MilestoneTimeline } from "@/components/dashboard/milestone-timeline"
import { WalletPanel } from "@/components/dashboard/wallet-panel"
import { InvestDialog } from "@/components/dashboard/invest-dialog"
import { ProjectDetailsDialog } from "@/components/dashboard/project-details-dialog"
import { PortfolioChart } from "@/components/dashboard/portfolio-chart"
import { FounderProjectForm } from "@/components/dashboard/founder-project-form"
import { ChatPanel } from "@/components/dashboard/chat-panel"
import { ProofSubmission } from "@/components/dashboard/proof-submission"
import { ProofOfUtilization } from "@/components/dashboard/proof-of-utilization"
import { AdminDashboard } from "@/components/dashboard/admin-dashboard"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  TrendingUp,
  DollarSign,
  Briefcase,
  Shield,
  Search,
  Rocket,
  CheckCircle,
  Clock,
} from "lucide-react"

const mockProjects: Project[] = [
  {
    id: "1",
    name: "NeuraTech AI",
    description:
      "Next-gen AI platform for enterprise automation and intelligent decision-making systems.",
    category: "AI/ML",
    fundingGoal: 500000,
    fundingRaised: 325000,
    milestones: 5,
    completedMilestones: 3,
    riskScore: 22,
    confidence: 87,
    daysLeft: 45,
    status: "active",
  },
  {
    id: "2",
    name: "EcoTrack",
    description:
      "Blockchain-based carbon footprint tracking and trading platform for sustainable businesses.",
    category: "Green Tech",
    fundingGoal: 300000,
    fundingRaised: 180000,
    milestones: 4,
    completedMilestones: 2,
    riskScore: 35,
    confidence: 78,
    daysLeft: 30,
    status: "active",
  },
  {
    id: "3",
    name: "HealthSync",
    description:
      "Decentralized health records management with AI-powered diagnostics assistance.",
    category: "Healthcare",
    fundingGoal: 750000,
    fundingRaised: 425000,
    milestones: 6,
    completedMilestones: 3,
    riskScore: 28,
    confidence: 82,
    daysLeft: 60,
    status: "active",
  },
  {
    id: "4",
    name: "FinFlow",
    description:
      "DeFi payment infrastructure for seamless cross-border transactions.",
    category: "Fintech",
    fundingGoal: 1000000,
    fundingRaised: 650000,
    milestones: 7,
    completedMilestones: 4,
    riskScore: 45,
    confidence: 72,
    daysLeft: 21,
    status: "active",
  },
  {
    id: "5",
    name: "AgriChain",
    description:
      "Supply chain transparency platform for agricultural products using IoT and blockchain.",
    category: "Agriculture",
    fundingGoal: 400000,
    fundingRaised: 120000,
    milestones: 5,
    completedMilestones: 1,
    riskScore: 55,
    confidence: 65,
    daysLeft: 90,
    status: "active",
  },
  {
    id: "6",
    name: "EduVerse",
    description:
      "Metaverse-based educational platform with immersive learning experiences.",
    category: "EdTech",
    fundingGoal: 250000,
    fundingRaised: 200000,
    milestones: 4,
    completedMilestones: 3,
    riskScore: 18,
    confidence: 91,
    daysLeft: 15,
    status: "active",
  },
]

const founderProjects: Project[] = [
  {
    id: "f1",
    name: "Your Project: DataMesh",
    description:
      "Distributed data processing platform for real-time analytics.",
    category: "Technology",
    fundingGoal: 200000,
    fundingRaised: 85000,
    milestones: 5,
    completedMilestones: 2,
    riskScore: 25,
    confidence: 85,
    daysLeft: 52,
    status: "active",
  },
]

export default function DashboardPage() {
  const router = useRouter()
  const [activeView, setActiveView] = useState("dashboard")
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [userRole, setUserRole] = useState<"investor" | "founder" | "admin">("investor")
  const [walletBalance, setWalletBalance] = useState(50000)
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [investDialogOpen, setInvestDialogOpen] = useState(false)
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null)

  useEffect(() => {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn")
    const storedRole = localStorage.getItem("userRole") as "investor" | "founder" | "admin" | null
    
    if (!isLoggedIn) {
      router.push("/login")
    } else if (storedRole) {
      setUserRole(storedRole)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn")
    localStorage.removeItem("userRole")
    router.push("/login")
  }

  const handleInvest = (project: Project) => {
    setSelectedProject(project)
    setInvestDialogOpen(true)
  }

  const handleViewDetails = (project: Project) => {
    setSelectedProject(project)
    setDetailsDialogOpen(true)
  }

  const handleInvestComplete = (amount: number) => {
    setWalletBalance((prev) => prev - amount)
  }

  const filteredProjects = mockProjects.filter((project) => {
    const matchesSearch =
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory =
      !categoryFilter || project.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  const categories = [...new Set(mockProjects.map((p) => p.category))]

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        isCollapsed={sidebarCollapsed}
        setIsCollapsed={setSidebarCollapsed}
        userRole={userRole}
        setUserRole={setUserRole}
        onLogout={handleLogout}
      />

      <div className="flex flex-1 flex-col overflow-hidden">
        <Header walletBalance={walletBalance} userRole={userRole} />

        <main className="flex-1 overflow-y-auto p-6">
          {/* Admin Views */}
          {userRole === "admin" && (
            <AdminDashboard />
          )}

          {/* Investor Views */}
          {userRole === "investor" && activeView === "dashboard" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Investor Dashboard
                </h1>
                <p className="text-sm text-muted-foreground">
                  Track your investments and discover new opportunities
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <StatsCard
                  title="Total Invested"
                  value="$125,000"
                  change="+12.5% from last month"
                  changeType="positive"
                  icon={DollarSign}
                />
                <StatsCard
                  title="Active Investments"
                  value="8"
                  change="2 pending verification"
                  changeType="neutral"
                  icon={Briefcase}
                />
                <StatsCard
                  title="Portfolio ROI"
                  value="+23.4%"
                  change="Above market average"
                  changeType="positive"
                  icon={TrendingUp}
                />
                <StatsCard
                  title="Risk Score"
                  value="Low"
                  change="Based on AI analysis"
                  changeType="positive"
                  icon={Shield}
                />
              </div>

              <PortfolioChart />

              <div className="grid gap-6 lg:grid-cols-3">
                <div className="lg:col-span-2">
                  <div className="mb-4 flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-foreground">
                      Recommended Projects
                    </h2>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setActiveView("discover")}
                    >
                      View All
                    </Button>
                  </div>
                  <div className="space-y-4">
                    {mockProjects.slice(0, 3).map((project) => (
                      <ProjectCard
                        key={project.id}
                        project={project}
                        onInvest={handleInvest}
                        onViewDetails={handleViewDetails}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <AIRiskPanel project={selectedProject || mockProjects[0]} />
                </div>
              </div>
            </div>
          )}

          {userRole === "investor" && activeView === "discover" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Discover Projects
                </h1>
                <p className="text-sm text-muted-foreground">
                  Find AI-verified investment opportunities
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search projects..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="border-border bg-background pl-10 text-foreground"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={categoryFilter === null ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCategoryFilter(null)}
                  >
                    All
                  </Button>
                  {categories.map((cat) => (
                    <Button
                      key={cat}
                      variant={categoryFilter === cat ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCategoryFilter(cat)}
                    >
                      {cat}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredProjects.map((project) => (
                  <ProjectCard
                    key={project.id}
                    project={project}
                    onInvest={handleInvest}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>

              {filteredProjects.length === 0 && (
                <div className="py-12 text-center">
                  <Search className="mx-auto h-12 w-12 text-muted-foreground" />
                  <p className="mt-4 text-lg font-medium text-foreground">
                    No projects found
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Try adjusting your search or filters
                  </p>
                </div>
              )}
            </div>
          )}

          {userRole === "investor" && activeView === "portfolio" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  My Portfolio
                </h1>
                <p className="text-sm text-muted-foreground">
                  Track your active investments and milestone progress
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <StatsCard
                  title="Total Value"
                  value="$152,400"
                  change="+18.2% all time"
                  changeType="positive"
                  icon={DollarSign}
                />
                <StatsCard
                  title="Pending Returns"
                  value="$12,500"
                  change="2 milestones pending"
                  changeType="neutral"
                  icon={Clock}
                />
                <StatsCard
                  title="Completed"
                  value="12"
                  change="Milestones verified"
                  changeType="positive"
                  icon={CheckCircle}
                />
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                <MilestoneTimeline />
                <BlockchainEscrow />
              </div>
            </div>
          )}

          {userRole === "investor" && activeView === "utilization" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Fund Utilization
                </h1>
                <p className="text-sm text-muted-foreground">
                  Track how founders are utilizing your invested funds
                </p>
              </div>
              <ProofOfUtilization isFounder={false} />
            </div>
          )}

          {userRole === "investor" && activeView === "messages" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Messages</h1>
                <p className="text-sm text-muted-foreground">
                  Communicate with founders and platform support
                </p>
              </div>
              <ChatPanel userRole={userRole} />
            </div>
          )}

          {userRole === "investor" && activeView === "wallet" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Wallet</h1>
                <p className="text-sm text-muted-foreground">
                  Manage your funds and view transaction history
                </p>
              </div>
              <div className="max-w-2xl">
                <WalletPanel
                  balance={walletBalance}
                  setBalance={setWalletBalance}
                />
              </div>
            </div>
          )}

          {userRole === "investor" && activeView === "analytics" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Analytics</h1>
                <p className="text-sm text-muted-foreground">
                  Deep dive into your investment performance
                </p>
              </div>
              <PortfolioChart />
              <div className="grid gap-6 lg:grid-cols-2">
                <BlockchainEscrow />
                <AIRiskPanel project={mockProjects[0]} />
              </div>
            </div>
          )}

          {/* Founder Views */}
          {userRole === "founder" && activeView === "dashboard" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Founder Dashboard
                </h1>
                <p className="text-sm text-muted-foreground">
                  Manage your projects and track funding progress
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <StatsCard
                  title="Total Raised"
                  value="$85,000"
                  change="+$15,000 this week"
                  changeType="positive"
                  icon={DollarSign}
                />
                <StatsCard
                  title="Active Projects"
                  value="1"
                  change="DataMesh in progress"
                  changeType="neutral"
                  icon={Rocket}
                />
                <StatsCard
                  title="Milestones"
                  value="2/5"
                  change="40% completed"
                  changeType="neutral"
                  icon={CheckCircle}
                />
                <StatsCard
                  title="Reputation"
                  value="92%"
                  change="Excellent standing"
                  changeType="positive"
                  icon={Shield}
                />
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                <div>
                  <h2 className="mb-4 text-lg font-semibold text-foreground">
                    Your Project
                  </h2>
                  <ProjectCard
                    project={founderProjects[0]}
                    onViewDetails={handleViewDetails}
                  />
                </div>
                <MilestoneTimeline isFounder />
              </div>

              <BlockchainEscrow />
            </div>
          )}

          {userRole === "founder" && activeView === "projects" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-foreground">
                    My Projects
                  </h1>
                  <p className="text-sm text-muted-foreground">
                    Create and manage your startup projects
                  </p>
                </div>
                <Badge variant="outline" className="text-sm">
                  1 Active Project
                </Badge>
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                <div>
                  <h2 className="mb-4 text-lg font-semibold text-foreground">
                    Current Project
                  </h2>
                  <ProjectCard
                    project={founderProjects[0]}
                    onViewDetails={handleViewDetails}
                  />
                </div>
                <FounderProjectForm />
              </div>
            </div>
          )}

          {userRole === "founder" && activeView === "milestones" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Milestone Management
                </h1>
                <p className="text-sm text-muted-foreground">
                  Track progress and upload verification proofs
                </p>
              </div>
              <div className="grid gap-6 lg:grid-cols-2">
                <MilestoneTimeline isFounder />
                <AIRiskPanel project={founderProjects[0]} />
              </div>
            </div>
          )}

          {userRole === "founder" && activeView === "proofs" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Submit Milestone Proofs
                </h1>
                <p className="text-sm text-muted-foreground">
                  Upload evidence to verify milestone completion
                </p>
              </div>
              <ProofSubmission isFounder />
            </div>
          )}

          {userRole === "founder" && activeView === "utilization" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Fund Utilization
                </h1>
                <p className="text-sm text-muted-foreground">
                  Document how you are using the received funds
                </p>
              </div>
              <ProofOfUtilization isFounder />
            </div>
          )}

          {userRole === "founder" && activeView === "messages" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Messages</h1>
                <p className="text-sm text-muted-foreground">
                  Communicate with investors and platform support
                </p>
              </div>
              <ChatPanel userRole={userRole} />
            </div>
          )}

          {userRole === "founder" && activeView === "wallet" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Funding Wallet
                </h1>
                <p className="text-sm text-muted-foreground">
                  Received funds and escrow status
                </p>
              </div>
              <div className="max-w-2xl">
                <WalletPanel
                  balance={walletBalance}
                  setBalance={setWalletBalance}
                />
              </div>
            </div>
          )}

          {userRole === "founder" && activeView === "analytics" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Project Analytics
                </h1>
                <p className="text-sm text-muted-foreground">
                  Funding metrics and investor insights
                </p>
              </div>
              <PortfolioChart />
              <BlockchainEscrow />
            </div>
          )}
        </main>
      </div>

      <InvestDialog
        project={selectedProject}
        isOpen={investDialogOpen}
        onClose={() => setInvestDialogOpen(false)}
        walletBalance={walletBalance}
        onInvestComplete={handleInvestComplete}
      />

      <ProjectDetailsDialog
        project={selectedProject}
        isOpen={detailsDialogOpen}
        onClose={() => setDetailsDialogOpen(false)}
        onInvest={handleInvest}
      />
    </div>
  )
}
