"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Shield, Users, Briefcase, UserCog, ArrowRight, Lock, Mail, User, Building2, Phone, Globe, FileText, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"

type UserRole = "admin" | "founder" | "investor"
type AuthMode = "login" | "signup"

const roleConfig = {
  admin: {
    icon: UserCog,
    title: "Admin Portal",
    description: "Manage platform operations, verify milestones, and oversee transactions",
    gradient: "from-amber-500/20 to-orange-500/20",
    iconColor: "text-amber-500",
    buttonClass: "bg-amber-600 hover:bg-amber-700",
    signupNote: "Admin accounts require platform approval",
  },
  founder: {
    icon: Briefcase,
    title: "Founder Portal",
    description: "Create projects, submit milestones, and manage your startup funding",
    gradient: "from-emerald-500/20 to-teal-500/20",
    iconColor: "text-emerald-500",
    buttonClass: "bg-emerald-600 hover:bg-emerald-700",
    signupNote: "Get your startup funded through milestone-based investments",
  },
  investor: {
    icon: Users,
    title: "Investor Portal",
    description: "Discover projects, invest in milestones, and track your portfolio",
    gradient: "from-primary/20 to-cyan-500/20",
    iconColor: "text-primary",
    buttonClass: "bg-primary hover:bg-primary/90",
    signupNote: "Start investing in verified startups with AI-powered insights",
  },
}

export default function LoginPage() {
  const router = useRouter()
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null)
  const [authMode, setAuthMode] = useState<AuthMode>("login")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [companyName, setCompanyName] = useState("")
  const [phone, setPhone] = useState("")
  const [website, setWebsite] = useState("")
  const [bio, setBio] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [signupSuccess, setSignupSuccess] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedRole) return

    setIsLoading(true)
    // Simulate login
    await new Promise((resolve) => setTimeout(resolve, 1000))
    
    // Store role in localStorage for demo
    localStorage.setItem("userRole", selectedRole)
    localStorage.setItem("isLoggedIn", "true")
    localStorage.setItem("userName", email.split("@")[0])
    
    router.push("/dashboard")
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedRole) return
    if (password !== confirmPassword) {
      alert("Passwords do not match")
      return
    }

    setIsLoading(true)
    // Simulate signup
    await new Promise((resolve) => setTimeout(resolve, 1500))
    
    setSignupSuccess(true)
    setIsLoading(false)
  }

  const resetForm = () => {
    setEmail("")
    setPassword("")
    setConfirmPassword("")
    setFullName("")
    setCompanyName("")
    setPhone("")
    setWebsite("")
    setBio("")
    setSignupSuccess(false)
  }

  const switchAuthMode = (mode: AuthMode) => {
    resetForm()
    setAuthMode(mode)
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-border px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
            <Shield className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">MilestoneChain AI</h1>
            <p className="text-xs text-muted-foreground">Blockchain & AI Powered Funding</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex flex-1 items-center justify-center p-6">
        <div className="w-full max-w-4xl">
          {!selectedRole ? (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold text-foreground">Welcome Back</h2>
                <p className="mt-2 text-muted-foreground">
                  Select your portal to continue
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                {(Object.keys(roleConfig) as UserRole[]).map((role) => {
                  const config = roleConfig[role]
                  const Icon = config.icon
                  return (
                    <button
                      key={role}
                      onClick={() => setSelectedRole(role)}
                      className={cn(
                        "group relative overflow-hidden rounded-xl border border-border bg-card p-6 text-left transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5"
                      )}
                    >
                      <div
                        className={cn(
                          "absolute inset-0 bg-gradient-to-br opacity-0 transition-opacity group-hover:opacity-100",
                          config.gradient
                        )}
                      />
                      <div className="relative">
                        <div
                          className={cn(
                            "mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-secondary",
                            config.iconColor
                          )}
                        >
                          <Icon className="h-6 w-6" />
                        </div>
                        <h3 className="text-lg font-semibold text-foreground">
                          {config.title}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                          {config.description}
                        </p>
                        <div className="mt-4 flex items-center gap-2 text-sm font-medium text-primary">
                          Continue
                          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>
          ) : (
            <div className="mx-auto max-w-md">
              <button
                onClick={() => {
                  setSelectedRole(null)
                  resetForm()
                  setAuthMode("login")
                }}
                className="mb-6 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
              >
                <ArrowRight className="h-4 w-4 rotate-180" />
                Back to portal selection
              </button>

              <Card className="border-border bg-card">
                <CardHeader className="text-center">
                  <div
                    className={cn(
                      "mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-secondary",
                      roleConfig[selectedRole].iconColor
                    )}
                  >
                    {(() => {
                      const Icon = roleConfig[selectedRole].icon
                      return <Icon className="h-8 w-8" />
                    })()}
                  </div>
                  <CardTitle className="text-xl">
                    {roleConfig[selectedRole].title}
                  </CardTitle>
                  <CardDescription>
                    {authMode === "login" 
                      ? "Enter your credentials to access your account"
                      : roleConfig[selectedRole].signupNote
                    }
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {signupSuccess ? (
                    <div className="space-y-4 text-center py-4">
                      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/20">
                        <CheckCircle2 className="h-8 w-8 text-success" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">Registration Successful!</h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                          {selectedRole === "admin" 
                            ? "Your admin account request has been submitted. You will receive an email once approved."
                            : "Your account has been created. Please check your email to verify your account."
                          }
                        </p>
                      </div>
                      <Button
                        onClick={() => switchAuthMode("login")}
                        className={cn("w-full", roleConfig[selectedRole].buttonClass)}
                      >
                        Back to Sign In
                      </Button>
                    </div>
                  ) : authMode === "login" ? (
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            id="email"
                            type="email"
                            placeholder="name@company.com"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="password">Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            id="password"
                            type="password"
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <label className="flex items-center gap-2 text-muted-foreground">
                          <input type="checkbox" className="rounded border-border" />
                          Remember me
                        </label>
                        <a href="#" className="text-primary hover:underline">
                          Forgot password?
                        </a>
                      </div>
                      <Button
                        type="submit"
                        className={cn("w-full", roleConfig[selectedRole].buttonClass)}
                        disabled={isLoading}
                      >
                        {isLoading ? "Signing in..." : "Sign In"}
                      </Button>
                      <p className="text-center text-sm text-muted-foreground">
                        {"Don't have an account? "}
                        <button 
                          type="button"
                          onClick={() => switchAuthMode("signup")}
                          className="text-primary hover:underline"
                        >
                          Sign Up
                        </button>
                      </p>
                    </form>
                  ) : (
                    <form onSubmit={handleSignup} className="space-y-4">
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="fullName">Full Name</Label>
                          <div className="relative">
                            <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                            <Input
                              id="fullName"
                              type="text"
                              placeholder="John Doe"
                              value={fullName}
                              onChange={(e) => setFullName(e.target.value)}
                              className="pl-10"
                              required
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="signupEmail">Email</Label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                            <Input
                              id="signupEmail"
                              type="email"
                              placeholder="name@company.com"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              className="pl-10"
                              required
                            />
                          </div>
                        </div>
                      </div>
                      
                      {(selectedRole === "founder" || selectedRole === "investor") && (
                        <div className="grid gap-4 sm:grid-cols-2">
                          <div className="space-y-2">
                            <Label htmlFor="companyName">
                              {selectedRole === "founder" ? "Startup Name" : "Company/Organization"}
                            </Label>
                            <div className="relative">
                              <Building2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                              <Input
                                id="companyName"
                                type="text"
                                placeholder={selectedRole === "founder" ? "Your Startup" : "Your Company"}
                                value={companyName}
                                onChange={(e) => setCompanyName(e.target.value)}
                                className="pl-10"
                                required
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="phone">Phone Number</Label>
                            <div className="relative">
                              <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                              <Input
                                id="phone"
                                type="tel"
                                placeholder="+1 (555) 000-0000"
                                value={phone}
                                onChange={(e) => setPhone(e.target.value)}
                                className="pl-10"
                              />
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {selectedRole === "founder" && (
                        <div className="space-y-2">
                          <Label htmlFor="website">Website (Optional)</Label>
                          <div className="relative">
                            <Globe className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                            <Input
                              id="website"
                              type="url"
                              placeholder="https://yourstartup.com"
                              value={website}
                              onChange={(e) => setWebsite(e.target.value)}
                              className="pl-10"
                            />
                          </div>
                        </div>
                      )}
                      
                      {selectedRole === "admin" && (
                        <div className="space-y-2">
                          <Label htmlFor="adminBio">Why do you want admin access?</Label>
                          <div className="relative">
                            <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Textarea
                              id="adminBio"
                              placeholder="Please describe your role and reason for admin access..."
                              value={bio}
                              onChange={(e) => setBio(e.target.value)}
                              className="min-h-[80px] pl-10 resize-none"
                              required
                            />
                          </div>
                        </div>
                      )}
                      
                      {selectedRole === "investor" && (
                        <div className="space-y-2">
                          <Label htmlFor="investorBio">Investment Focus (Optional)</Label>
                          <div className="relative">
                            <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Textarea
                              id="investorBio"
                              placeholder="What sectors or stages are you interested in investing in?"
                              value={bio}
                              onChange={(e) => setBio(e.target.value)}
                              className="min-h-[60px] pl-10 resize-none"
                            />
                          </div>
                        </div>
                      )}
                      
                      {selectedRole === "founder" && (
                        <div className="space-y-2">
                          <Label htmlFor="founderBio">Brief Description of Your Startup</Label>
                          <div className="relative">
                            <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Textarea
                              id="founderBio"
                              placeholder="Describe your startup idea in a few sentences..."
                              value={bio}
                              onChange={(e) => setBio(e.target.value)}
                              className="min-h-[60px] pl-10 resize-none"
                              required
                            />
                          </div>
                        </div>
                      )}

                      <div className="grid gap-4 sm:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="signupPassword">Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                            <Input
                              id="signupPassword"
                              type="password"
                              placeholder="Create password"
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              className="pl-10"
                              required
                              minLength={8}
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="confirmPassword">Confirm Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                            <Input
                              id="confirmPassword"
                              type="password"
                              placeholder="Confirm password"
                              value={confirmPassword}
                              onChange={(e) => setConfirmPassword(e.target.value)}
                              className="pl-10"
                              required
                              minLength={8}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-2 text-sm">
                        <input type="checkbox" className="mt-1 rounded border-border" required />
                        <span className="text-muted-foreground">
                          I agree to the{" "}
                          <a href="#" className="text-primary hover:underline">Terms of Service</a>
                          {" "}and{" "}
                          <a href="#" className="text-primary hover:underline">Privacy Policy</a>
                        </span>
                      </div>
                      
                      <Button
                        type="submit"
                        className={cn("w-full", roleConfig[selectedRole].buttonClass)}
                        disabled={isLoading}
                      >
                        {isLoading ? "Creating Account..." : "Create Account"}
                      </Button>
                      <p className="text-center text-sm text-muted-foreground">
                        Already have an account?{" "}
                        <button 
                          type="button"
                          onClick={() => switchAuthMode("login")}
                          className="text-primary hover:underline"
                        >
                          Sign In
                        </button>
                      </p>
                    </form>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border px-6 py-4">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <p>2024 MilestoneChain AI. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-foreground">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-foreground">
              Terms of Service
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}
